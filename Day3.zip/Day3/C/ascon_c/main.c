#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "api.h"
#include "core.h"
#include "ascon.h"

#define MAX_INPUT_SIZE     256
#define ASCON_HASH_SIZE    32

// External function prototypes
extern int crypto_aead_encrypt(unsigned char* c, unsigned long long* clen,
                            const unsigned char* m, unsigned long long mlen,
                            const unsigned char* ad, unsigned long long adlen,
                            const unsigned char* nsec, const unsigned char* npub,
                            const unsigned char* k);

extern int crypto_aead_decrypt(unsigned char* m, unsigned long long* mlen,
                            unsigned char* nsec, const unsigned char* c,
                            unsigned long long clen, const unsigned char* ad,
                            unsigned long long adlen, const unsigned char* npub,
                            const unsigned char* k);

extern int crypto_hash(unsigned char* out, const unsigned char* in,
               unsigned long long inlen);

// Helper to print bytes in hex
void print_hex(const char* label, const unsigned char* data, size_t len) {
    printf("%s: ", label);
    for (size_t i = 0; i < len; i++) {
        printf("%02x", data[i]);
    }
    printf("\n");
}

// Generate random bytes using standard C library
void generate_random_bytes(unsigned char *buf, size_t len) {
    for (size_t i = 0; i < len; i++) {
        buf[i] = rand() & 0xFF;
    }
}

// Read line safely from stdin
int read_line(char* buffer, size_t max_len) {
    if (fgets(buffer, max_len, stdin) == NULL) {
        return 0;
    }
    
    // Remove trailing newline
    size_t len = strlen(buffer);
    if (len > 0 && (buffer[len-1] == '\n' || buffer[len-1] == '\r')) {
        buffer[len-1] = '\0';
        len--;
    }
    if (len > 0 && (buffer[len-1] == '\n' || buffer[len-1] == '\r')) {
        buffer[len-1] = '\0';
        len--;
    }
    
    return len;
}

// Interactive ASCON AEAD demo
void ascon_aead_demo_interactive(void) {
    unsigned char key[CRYPTO_KEYBYTES];
    unsigned char nonce[CRYPTO_NPUBBYTES];
    const unsigned char ad[] = "Associated Data";

    unsigned char ciphertext[MAX_INPUT_SIZE + CRYPTO_ABYTES];
    unsigned char decrypted[MAX_INPUT_SIZE];
    unsigned long long clen = 0, mlen = 0;
    char plaintext[MAX_INPUT_SIZE];
    size_t input_len = 0;
    int choice;

    printf("ASCON AEAD Interactive Demo Started\n");

    while (1) {
        printf("\n=== ASCON AEAD Demo ===\n");
        printf("1. Encrypt message\n");
        printf("2. Decrypt last message\n");
        printf("3. Hash the Message\n");
        printf("4. Exit\n");
        printf("Select option (1-4): ");
        fflush(stdout);

        char choice_buf[10];
        read_line(choice_buf, sizeof(choice_buf));
        choice = atoi(choice_buf);

        switch (choice) {
            case 1:
                printf("\nEnter plaintext message: ");
                fflush(stdout);
                input_len = read_line(plaintext, sizeof(plaintext));
                printf("Length: %zu\n", input_len);
                
                if (input_len <= 0) {
                    printf("Empty input. Try again.\n");
                    break;
                }

                // Generate random key and nonce
                generate_random_bytes(key, CRYPTO_KEYBYTES);
                generate_random_bytes(nonce, CRYPTO_NPUBBYTES);

                printf("\nPlaintext: %s\n", plaintext);
                print_hex("Key", key, CRYPTO_KEYBYTES);
                print_hex("Nonce", nonce, CRYPTO_NPUBBYTES);
                print_hex("Associated Data", ad, sizeof(ad) - 1);

                // Encrypt
                if (crypto_aead_encrypt(ciphertext, &clen,
                                        (unsigned char*)plaintext, input_len,
                                        ad, sizeof(ad) - 1,
                                        NULL, nonce, key) == 0) {
                    print_hex("Ciphertext", ciphertext, input_len);
                    print_hex("Authentication Tag", ciphertext + input_len, CRYPTO_ABYTES);
                    printf("Encryption completed successfully\n");
                } else {
                    printf("Encryption failed!\n");
                }
                break;

            case 2:
                if (clen == 0) {
                    printf("No ciphertext to decrypt. Encrypt first.\n");
                    break;
                }
                
                printf("\nAttempting to decrypt last ciphertext...\n");
                print_hex("Nonce", nonce, CRYPTO_NPUBBYTES);
                print_hex("Associated Data", ad, sizeof(ad) - 1);
                print_hex("Ciphertext", ciphertext, clen - CRYPTO_ABYTES);
                print_hex("Authentication Tag", ciphertext + (clen - CRYPTO_ABYTES), CRYPTO_ABYTES);

                if (crypto_aead_decrypt(decrypted, &mlen, NULL,
                                        ciphertext, clen,
                                        ad, sizeof(ad) - 1,
                                        nonce, key) == 0) {
                    decrypted[mlen] = '\0';
                    printf("Decryption successful!\n");
                    printf("Decrypted text: %s\n", (char*)decrypted);
                } else {
                    printf("Authentication failed! Tag mismatch.\n");
                }
                break;

            case 3: {
                printf("\n=== Testing Hash ===\n");

                unsigned char message[128];
                unsigned char hash[ASCON_HASH_SIZE];

                // Get message from stdin
                printf("Enter message to hash: ");
                fflush(stdout);

                read_line((char*)message, sizeof(message));
                unsigned long long msg_len = strlen((char*)message);

                printf("\nHashing...\n");

                // Hash the message
                int result = crypto_hash(hash, message, msg_len);

                if (result == 0) {
                    print_hex("Hash", hash, ASCON_HASH_SIZE);
                    printf("Hashing successful!\n");
                } else {
                    printf("Hashing failed!\n");
                }
                break;
            }

            case 4:
                printf("Exiting demo...\n");
                return;

            default:
                printf("Invalid choice. Try again.\n");
                break;
        }
    }
}

int main(void) {
    // Seed random number generator
    srand(time(NULL));

    printf("\n=== ASCON AEAD Interactive Demonstration ===\n");
    printf("ASCON Version: %s\n", CRYPTO_VERSION);
    printf("Key size: %d bytes\n", CRYPTO_KEYBYTES);
    printf("Nonce size: %d bytes\n", CRYPTO_NPUBBYTES);
    printf("Tag size: %d bytes\n", CRYPTO_ABYTES);
    printf("Enter messages via stdin\n");

    ascon_aead_demo_interactive();

    return 0;
}