#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "poly1305.h"
#include <ctype.h>
#include "sha3_256.h"

#if defined(_WIN32)
#include <windows.h>
#include <wincrypt.h>
#pragma comment(lib, "advapi32.lib")

int csprng_get_bytes(uint8_t *buf, size_t len) {
    HCRYPTPROV hProv;
    if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
        return -1;
    BOOL ok = CryptGenRandom(hProv, (DWORD)len, buf);
    CryptReleaseContext(hProv, 0);
    return ok ? 0 : -1;
}

#elif defined(__linux__) || defined(__APPLE__)
#include <fcntl.h>
#include <unistd.h>

int csprng_get_bytes(uint8_t *buf, size_t len) {
    int fd = open("/dev/urandom", O_RDONLY);
    if (fd < 0) return -1;
    size_t off = 0;
    while (off < len) {
        ssize_t r = read(fd, buf + off, len - off);
        if (r <= 0) { close(fd); return -1; }
        off += (size_t)r;
    }
    close(fd);
    return 0;
}
#else
#error "No secure RNG available on this platform."
#endif

/* -------------------- ChaCha20 -------------------- */
#define ROTL32(x,n) (((x) << (n)) | ((x) >> (32-(n))))
#define QR(a,b,c,d) do { a+=b; d^=a; d=ROTL32(d,16); c+=d; b^=c; b=ROTL32(b,12); a+=b; d^=a; d=ROTL32(d,8); c+=d; b^=c; b=ROTL32(b,7); } while(0)

static void chacha20_block(uint32_t out[16], const uint32_t in[16]) {
    int i;
    uint32_t x[16];
    for(i=0;i<16;i++) x[i]=in[i];
    for(i=0;i<10;i++){
        // column rounds
        QR(x[0],x[4],x[8],x[12]);
        QR(x[1],x[5],x[9],x[13]);
        QR(x[2],x[6],x[10],x[14]);
        QR(x[3],x[7],x[11],x[15]);
        // diagonal rounds
        QR(x[0],x[5],x[10],x[15]);
        QR(x[1],x[6],x[11],x[12]);
        QR(x[2],x[7],x[8],x[13]);
        QR(x[3],x[4],x[9],x[14]);
    }
    for(i=0;i<16;i++) out[i]=x[i]+in[i];
}

static void chacha20_init(uint32_t state[16], const uint8_t key[32], uint32_t counter, const uint8_t nonce[12]) {
    state[0]=0x61707865; state[1]=0x3320646e; state[2]=0x79622d32; state[3]=0x6b206574;
    for(int i=0;i<8;i++){
        state[4+i] = ((uint32_t)key[i*4+0]) | ((uint32_t)key[i*4+1]<<8) | ((uint32_t)key[i*4+2]<<16) | ((uint32_t)key[i*4+3]<<24);
    }
    state[12]=counter;
    state[13]=((uint32_t)nonce[0]) | ((uint32_t)nonce[1]<<8) | ((uint32_t)nonce[2]<<16) | ((uint32_t)nonce[3]<<24);
    state[14]=((uint32_t)nonce[4]) | ((uint32_t)nonce[5]<<8) | ((uint32_t)nonce[6]<<16) | ((uint32_t)nonce[7]<<24);
    state[15]=((uint32_t)nonce[8]) | ((uint32_t)nonce[9]<<8) | ((uint32_t)nonce[10]<<16) | ((uint32_t)nonce[11]<<24);
}

static void chacha20_xor(uint8_t *out, const uint8_t *in, size_t len, const uint8_t key[32], uint32_t counter, const uint8_t nonce[12]){
    uint8_t block[64];
    uint32_t state[16], tmp[16];
    size_t offset=0;
    while(offset<len){
        chacha20_init(state,key,counter,nonce);
        chacha20_block(tmp,state);
        for(int i=0;i<16;i++){
            block[i*4+0]=(uint8_t)(tmp[i]&0xff);
            block[i*4+1]=(uint8_t)((tmp[i]>>8)&0xff);
            block[i*4+2]=(uint8_t)((tmp[i]>>16)&0xff);
            block[i*4+3]=(uint8_t)((tmp[i]>>24)&0xff);
        }
        size_t n=(len-offset>64)?64:(len-offset);
        for(size_t i=0;i<n;i++) out[offset+i]=in[offset+i]^block[i];
        offset+=n; counter++;
    }
}

static void chacha20_block0_keystream(uint8_t out[64], const uint8_t key[32], const uint8_t nonce[12]){
    uint32_t state[16], block[16];
    chacha20_init(state,key,0,nonce);
    chacha20_block(block,state);
    for(int i=0;i<16;i++){
        out[i*4+0]=(uint8_t)(block[i]&0xff);
        out[i*4+1]=(uint8_t)((block[i]>>8)&0xff);
        out[i*4+2]=(uint8_t)((block[i]>>16)&0xff);
        out[i*4+3]=(uint8_t)((block[i]>>24)&0xff);
    }
}

/* -------------------- Poly1305 -------------------- */

typedef struct {
    uint32_t r[5];
    uint32_t h[5];
    uint32_t pad[4];
} poly1305_ctx;

static uint32_t U32LE(const uint8_t *p){return ((uint32_t)p[0])|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static void le_store_u64(uint8_t out[8], uint64_t v){for(int i=0;i<8;i++){out[i]=(uint8_t)(v&0xff);v>>=8;}}

// /* Minimal Poly1305 (RFC 8439) */
// static void poly1305_auth(uint8_t out[16], const uint8_t *m, size_t len, const uint8_t key[32]);

/* -------------------- AEAD -------------------- */

void aead_chacha20_poly1305_encrypt(
    const uint8_t key[32], const uint8_t nonce[12],
    const uint8_t *aad, size_t aad_len,
    const uint8_t *plaintext, size_t plen,
    uint8_t *ciphertext, uint8_t tag[16]) 
{
    uint8_t block0[64];
    chacha20_block0_keystream(block0,key,nonce);
    uint8_t poly_key[32]; memcpy(poly_key,block0,32);

    if(plen>0) chacha20_xor(ciphertext,plaintext,plen,key,1,nonce);

    size_t aad_pad=(16-(aad_len%16))%16;
    size_t ct_pad=(16-(plen%16))%16;
    size_t mac_len=aad_len+aad_pad+plen+ct_pad+16;
    uint8_t *mac_buf=(uint8_t*)malloc(mac_len); 
    if(!mac_buf){fprintf(stderr,"malloc failed\n"); exit(1);}
    uint8_t *p=mac_buf;
    if(aad_len){memcpy(p,aad,aad_len); p+=aad_len;}
    if(aad_pad){memset(p,0,aad_pad); p+=aad_pad;}
    if(plen){memcpy(p,ciphertext,plen); p+=plen;}
    if(ct_pad){memset(p,0,ct_pad); p+=ct_pad;}
    uint8_t le8[8];
    le_store_u64(le8,(uint64_t)aad_len); memcpy(p,le8,8); p+=8;
    le_store_u64(le8,(uint64_t)plen); memcpy(p,le8,8);

    poly1305_auth(tag,mac_buf,mac_len,poly_key);
    memset(mac_buf,0,mac_len); free(mac_buf);
    memset(block0,0,sizeof(block0)); memset(poly_key,0,sizeof(poly_key));
}

int aead_chacha20_poly1305_decrypt(
    const uint8_t key[32], const uint8_t nonce[12],
    const uint8_t *aad, size_t aad_len,
    const uint8_t *ciphertext, size_t clen,
    const uint8_t tag[16],
    uint8_t *plaintext)
{
    uint8_t block0[64];
    chacha20_block0_keystream(block0,key,nonce);
    uint8_t poly_key[32]; memcpy(poly_key,block0,32);

    size_t aad_pad=(16-(aad_len%16))%16;
    size_t ct_pad=(16-(clen%16))%16;
    size_t mac_len=aad_len+aad_pad+clen+ct_pad+16;
    uint8_t *mac_buf=(uint8_t*)malloc(mac_len);
    if(!mac_buf){fprintf(stderr,"malloc failed\n"); exit(1);}
    uint8_t *p=mac_buf;
    if(aad_len){memcpy(p,aad,aad_len); p+=aad_len;}
    if(aad_pad){memset(p,0,aad_pad); p+=aad_pad;}
    if(clen){memcpy(p,ciphertext,clen); p+=clen;}
    if(ct_pad){memset(p,0,ct_pad); p+=ct_pad;}
    uint8_t le8[8];
    le_store_u64(le8,(uint64_t)aad_len); memcpy(p,le8,8); p+=8;
    le_store_u64(le8,(uint64_t)clen); memcpy(p,le8,8);

    uint8_t calc_tag[16];
    poly1305_auth(calc_tag,mac_buf,mac_len,poly_key);
    memset(mac_buf,0,mac_len); free(mac_buf);

    int ok=1;
    for(int i=0;i<16;i++) ok&=(calc_tag[i]==tag[i]);
    if(!ok) return -1;

    if(clen>0) chacha20_xor(plaintext,ciphertext,clen,key,1,nonce);
    memset(block0,0,sizeof(block0)); memset(poly_key,0,sizeof(poly_key));
    return 0;
}

/* -------------------- Utility -------------------- */
static void print_hex(const char *label, const uint8_t *b, size_t len){
    printf("%s",label); for(size_t i=0;i<len;i++) printf("%02x",b[i]); printf("\n");
}

int hex_to_bytes(const char *hex, uint8_t *out, size_t out_max)
{
    size_t len = strlen(hex);
    if (len % 2 != 0) {
        return -1; // Invalid hex string length
    }

    size_t bytes_len = len / 2;
    if (bytes_len > out_max) {
        return -2; // Output buffer too small
    }

    for (size_t i = 0; i < bytes_len; i++) {
        char c1 = hex[2 * i];
        char c2 = hex[2 * i + 1];

        if (!isxdigit(c1) || !isxdigit(c2)) {
            return -3; // Invalid hex character
        }

        uint8_t hi = (uint8_t)(isdigit(c1) ? c1 - '0' : (tolower(c1) - 'a' + 10));
        uint8_t lo = (uint8_t)(isdigit(c2) ? c2 - '0' : (tolower(c2) - 'a' + 10));

        out[i] = (hi << 4) | lo;
    }
    return (int)bytes_len; // return number of bytes converted
}

/* -------------------- Main Test -------------------- */
int main(int argc, char **argv){

    uint8_t key[32];
    uint8_t digest[32], nonce[12];
    uint8_t aad[32];
    const char *pt_str=argv[1];
    const char *ad_string =argv[2];
    const uint8_t *plaintext=(const uint8_t *)pt_str;
    size_t plen=strlen(pt_str);
    
    printf("\t------------------");
    printf("\n\tChacha20-Poly1305\n");
    printf("\t------------------\n");

    printf("\n\tPlain Text: %s\n",pt_str);
    csprng_get_bytes(key,32);
    print_hex("\n\tKey: ",key,sizeof(key));

    csprng_get_bytes(nonce,12);

    print_hex("\n\tNonce: ",nonce,sizeof(nonce));
    sha3_256(ad_string,strlen(ad_string),digest);
    memcpy(aad,digest,32);
    print_hex("\n\tAssocaited Data: ",aad,sizeof(aad));
    uint8_t ciphertext[1024];
    uint8_t tag[16];

    aead_chacha20_poly1305_encrypt(key,nonce,aad,sizeof(aad),plaintext,plen,ciphertext,tag);
    print_hex("\n\tCiphertext: ",ciphertext,plen);
    print_hex("\n\tTag: ",tag,16);

    uint8_t recovered[1024];
    int ok=aead_chacha20_poly1305_decrypt(key,nonce,aad,sizeof(aad),ciphertext,plen,tag,recovered);
    printf("\n\tDecrypt verify: %s\n",ok==0?"OK":"FAIL");
    if(ok==0) printf("\n\tRecovered plaintext:%.*s\n\n",(int)plen,recovered);

    return 0;
}
