#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "esp_system.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "api.h"
#include "core.h"
// #include "printstate.h"
#include "ascon.h"
// #include "constants.h"
#include "esp_random.h"

#define UART_PORT_NUM      UART_NUM_0
#define UART_BAUD_RATE     115200
#define BUF_SIZE           1024
#define MAX_INPUT_SIZE     256  // Changed from MAX_INPUT to avoid conflict

#define ASCON_HASH_SIZE  32

// External function prototypes
extern int crypto_aead_encrypt(unsigned char* c, unsigned long long* clen,
                            const unsigned char* m, unsigned long long mlen,
                            const unsigned char* ad, unsigned long long adlen,
                            const unsigned char* nsec, const unsigned char* npub,
                            const unsigned char* k);

extern int crypto_aead_decrypt(unsigned char* m, unsigned long long* mlen,
                            unsigned char* nsec, const unsigned char* c,
                            unsigned long long clen, const unsigned char* ad,
                            unsigned long long adlen, const unsigned char* npub,
                            const unsigned char* k);


extern int crypto_hash(unsigned char* out, const unsigned char* in,
               unsigned long long inlen);

// Helper to print bytes in hex
void print_hex(const char* label, const unsigned char* data, size_t len) {
    printf("%s: ", label);
    for (size_t i = 0; i < len; i++) {
        printf("%02x", data[i]);
    }
    printf("\n");
}

void generate_random_bytes(uint8_t *buf, size_t len) {
    for (size_t i = 0; i < len; i++) {
        buf[i] = esp_random() & 0xFF;
    }
}

// Read line safely from UART
int uart_read_line(char* buffer, size_t max_len) {
    int len = 0;
    int c;
    while (len < max_len - 1) {
        c = getchar();
        if (c == EOF) {
            vTaskDelay(10 / portTICK_PERIOD_MS);
            continue;
        }
        if (c == '\n' || c == '\r') {
            buffer[len] = '\0';
            return len;
        }
        if (c == 127 || c == 8) { // Backspace
            if (len > 0) {
                len--;
                printf("\b \b");
                fflush(stdout);
            }
            continue;
        }
        buffer[len++] = (char)c;
        putchar(c);
        fflush(stdout);
    }
    buffer[len] = '\0';
    return len;
}

// Interactive ASCON AEAD demo over UART
void ascon_aead_demo_interactive(void) {
    unsigned char key[CRYPTO_KEYBYTES];
    unsigned char nonce[CRYPTO_NPUBBYTES]; // Use same size as key for nonce
    const unsigned char ad[] = "Associated Data";

    unsigned char ciphertext[MAX_INPUT_SIZE + CRYPTO_ABYTES];
    unsigned char decrypted[MAX_INPUT_SIZE];
    unsigned long long clen = 0, mlen = 0;
    char plaintext[MAX_INPUT_SIZE];
    size_t input_len = 0;
    int choice;

    ESP_LOGI("ASCON", "ASCON AEAD Interactive Demo Started");

    while (1) {
        printf("\n=== ASCON AEAD Demo ===\n");
        printf("1. Encrypt message\n");
        printf("2. Decrypt last message\n");
        printf("3. Hash the Message\n");
        printf("4. Exit\n");
        printf("Select option (1-4): ");
        fflush(stdout);

        char choice_buf[10];
        uart_read_line(choice_buf, sizeof(choice_buf));
        choice = atoi(choice_buf);

        switch (choice) {
            case 1:
                printf("\nEnter plaintext message: ");
                fflush(stdout);
                input_len = uart_read_line(plaintext, sizeof(plaintext));
                printf("%d\n",input_len);
                if (input_len <= 0) {
                    printf("Empty input. Try again.\n");
                    break;
                }

                // Generate random key and nonce
                generate_random_bytes(key, CRYPTO_KEYBYTES);
                generate_random_bytes(nonce, CRYPTO_NPUBBYTES);

                printf("\nPlaintext: %s\n", plaintext);
                print_hex("Key", key, CRYPTO_KEYBYTES);
                print_hex("Nonce", nonce, CRYPTO_NPUBBYTES);
                print_hex("Associated Data", ad, sizeof(ad) - 1);

                // Encrypt
                if (crypto_aead_encrypt(ciphertext, &clen,
                                        (unsigned char*)plaintext, input_len,
                                        ad, sizeof(ad) - 1,
                                        NULL, nonce, key) == 0) {
                    print_hex("Ciphertext", ciphertext, input_len);
                    print_hex("Authentication Tag", ciphertext + input_len, CRYPTO_ABYTES);
                    printf("Encryption completed successfully\n");
                } else {
                    printf("Encryption failed!\n");
                }
                break;

            case 2:
                if (clen == 0) {
                    printf("No ciphertext to decrypt. Encrypt first.\n");
                    break;
                }
                
                printf("\nAttempting to decrypt last ciphertext...\n");
                print_hex("Nonce", nonce, CRYPTO_NPUBBYTES);
                print_hex("Associated Data", ad, sizeof(ad) - 1);
                print_hex("Ciphertext", ciphertext, clen - CRYPTO_ABYTES);
                print_hex("Authentication Tag", ciphertext + (clen - CRYPTO_ABYTES), CRYPTO_ABYTES);

                if (crypto_aead_decrypt(decrypted, &mlen, NULL,
                                        ciphertext, clen,
                                        ad, sizeof(ad) - 1,
                                        nonce, key) == 0) {
                    decrypted[mlen] = '\0';
                    printf("Decryption successful!\n");
                    printf("Decrypted text: %s\n", (char*)decrypted);
                } else {
                    printf("Authentication failed! Tag mismatch.\n");
                }
                break;
            case 3:

                printf("\n=== Testing Hash ===\n");

                unsigned char message[128];
                unsigned char hash[ASCON_HASH_SIZE];

                // Get message from UART
                printf("Enter message to hash: ");
                fflush(stdout);  // Force the message to appear immediately

                uart_read_line((char*)message, sizeof(message));
                unsigned long long mlen = strlen((char*)message);

                printf("\nHashing...\n");

                // Hash the message
                int result = crypto_hash(hash, message, mlen);

                if (result == 0) {
                    print_hex("Hash", hash, ASCON_HASH_SIZE);
                    printf("Hashing successful!\n");
                } else {
                    printf("Hashing failed!\n");
                }
            break;
            case 4:
                printf("Exiting demo...\n");
                ESP_LOGI("ASCON", "Demo exited by user");
                return;

            default:
                printf("Invalid choice. Try again.\n");
                break;
        }

        vTaskDelay(500 / portTICK_PERIOD_MS);
    }
}

void app_main(void) {
    // UART setup
    uart_config_t uart_config = {
        .baud_rate = UART_BAUD_RATE,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE
    };
    uart_param_config(UART_PORT_NUM, &uart_config);
    // uart_driver_install(UART_PORT_NUM, BUF_SIZE * 2, 0, 0, NULL, 0);

    vTaskDelay(1000 / portTICK_PERIOD_MS); // Wait for serial monitor

    printf("\n=== ASCON AEAD Interactive Demonstration ===\n");
    printf("ASCON Version: %s\n", CRYPTO_VERSION);
    printf("Key size: %d bytes\n", CRYPTO_KEYBYTES);
    printf("Nonce size: %d bytes\n", CRYPTO_NPUBBYTES); // Nonce same size as key
    printf("Tag size: %d bytes\n", CRYPTO_ABYTES);
    printf("Enter messages via UART\n");

    ascon_aead_demo_interactive();
}
