from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from binascii import hexlify, unhexlify
import sys

# ========== ENCRYPTION ==========
def chacha20poly_encrypt(key_hex, nonce_hex, ad_hex, plaintext_str):
    key = unhexlify(key_hex)
    nonce = unhexlify(nonce_hex)
    ad = unhexlify(ad_hex) if ad_hex else b""
    plaintext = plaintext_str.encode()

    aead = ChaCha20Poly1305(key)
    ciphertext_with_tag = aead.encrypt(nonce, plaintext, ad)

    # Split ciphertext and tag (last 16 bytes are tag)
    ciphertext = ciphertext_with_tag[:-16]
    tag = ciphertext_with_tag[-16:]

    return ciphertext, tag


# ========== DECRYPTION ==========
def chacha20poly_decrypt(key_hex, nonce_hex, ad_hex, ciphertext_hex, tag_hex):
    key = unhexlify(key_hex)
    nonce = unhexlify(nonce_hex)
    ad = unhexlify(ad_hex) if ad_hex else b""
    ciphertext = unhexlify(ciphertext_hex)
    tag = unhexlify(tag_hex)

    aead = ChaCha20Poly1305(key)
    try:
        plaintext = aead.decrypt(nonce, ciphertext + tag, ad)
        return True, plaintext
    except Exception:
        return False, None


# ========== DEMO ==========
if __name__ == "__main__":
    # Example test vectors (replace with your values)

    if sys.argv[1] == "enc":
        input_text = input("Enter the plaintext : ")
        key_hex   = input("Enter the Key Value :")
        nonce_hex = input("Enter the Nonce Value :")
        ad_hex    = input("Enter the Associated Data :") 
        print("=== ChaCha20-Poly1305 Encryption ===")
        ciphertext, tag = chacha20poly_encrypt(key_hex, nonce_hex, ad_hex, input_text)
        print("Plaintext:", input_text)
        print("Ciphertext:", hexlify(ciphertext).decode())
        print("Tag:", hexlify(tag).decode())

    else:
        input_text = input("Enter the cipher text : ")
        key_hex   = input("Enter the Key Value :")
        nonce_hex = input("Enter the Nonce Value :")
        ad_hex    = input("Enter the Associated Data :")  # "Associated Data"
        tag = input("Enter the tag value : ")
        print("\n=== ChaCha20-Poly1305 Decryption ===")
        ok, recovered = chacha20poly_decrypt(
            key_hex,
            nonce_hex,
            ad_hex,
            input_text,
            tag
        )

        print("Authentication OK:", ok)
        if ok:
            print("Recovered plaintext:", recovered.decode())



