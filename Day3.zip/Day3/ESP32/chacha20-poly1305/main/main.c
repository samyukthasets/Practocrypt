#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_random.h"
#include "chachapoly.h"
#include "chacha.h"

#define TAG "ChaCha20"
#define MAX_SIZE_INPUT 256
// Function to print bytes in hex
void print_hex(const char *label, const unsigned char *data, size_t len) {
    printf("%s: ", label);
    for (size_t i = 0; i < len; i++) {
        printf("%02x", data[i]);
    }
    printf("\n");
}

// Function to read line from UART safely
int read_line(char *buffer, size_t max_len) {
    int len = 0;
    int c;

    while (len < max_len - 1) {
        c = getchar();

        if (c == EOF) {
            vTaskDelay(10 / portTICK_PERIOD_MS);
            continue;
        }

        if (c == '\n' || c == '\r') {
            buffer[len] = '\0';
            return len;
        }

        if (c == 127 || c == 8) { // Backspace
            if (len > 0) {
                len--;
                printf("\b \b");
                fflush(stdout);
            }
            continue;
        }

        buffer[len++] = (char)c;
        putchar(c);
        fflush(stdout);
    }

    buffer[len] = '\0';
    return len;
}

// Function to generate random data using ESP RNG
void generate_random_data(void *data, size_t len) {
    esp_fill_random(data, len);
}

void chachapoly_demo_interactive(void) {
    struct chachapoly_ctx ctx;
    unsigned char key[32];
    unsigned char nonce[12];
    unsigned char ad[] = "Associated Data";
    unsigned char plaintext[MAX_SIZE_INPUT];
    unsigned char ciphertext[MAX_SIZE_INPUT];
    unsigned char decrypted[MAX_SIZE_INPUT];
    unsigned char tag[16];
    int choice;
    int input_len = 0;

    ESP_LOGI(TAG, "ChaCha20-Poly1305 Interactive Demo Started");

    while (1) {
        printf("\n\n=== ChaCha20-Poly1305 AEAD Demo ===\n");
        printf("1. Encrypt message\n");
        printf("2. Decrypt last message\n");
        printf("3. Exit\n");
        printf("Select option (1-3): ");
        fflush(stdout);

        char choice_buf[10];
        read_line(choice_buf, sizeof(choice_buf));
        choice = atoi(choice_buf);

        switch (choice) {
            case 1:
                printf("\nEnter plaintext message: ");
                fflush(stdout);
                input_len = read_line((char *)plaintext, sizeof(plaintext));

                if (input_len <= 0) {
                    printf("Empty input. Try again.\n");
                    break;
                }

                // Generate random key and nonce
                generate_random_data(key, sizeof(key));
                generate_random_data(nonce, sizeof(nonce));

                printf("\nPlaintext: %s\n", plaintext);
                print_hex("Key", key, sizeof(key));
                print_hex("Nonce", nonce, sizeof(nonce));
                print_hex("Associated Data", ad, sizeof(ad) - 1);

                // Initialize ChaChaPoly
                chachapoly_init(&ctx, key, 256);

                    // Encrypt
                    chachapoly_crypt(&ctx, nonce, ad, sizeof(ad) - 1,
                                    plaintext, input_len,
                                    ciphertext, tag, sizeof(tag), 1);
                print_hex("\nCiphertext", ciphertext, input_len);
                print_hex("Authentication Tag", tag, sizeof(tag));

                ESP_LOGI(TAG, "Encryption completed successfully");
                break;


                                    
                case 2:
                    printf("\nAttempting to decrypt last ciphertext...\n");

                    // Print all values being used for decryption
                    printf("Ciphertext to decrypt: ");
                    for (int i = 0; i < input_len; i++) {
                        printf("%02x", ciphertext[i]);
                    }
                    printf("\n");

                    printf("Nonce used: ");
                    for (int i = 0; i < sizeof(nonce); i++) {
                        printf("%02x", nonce[i]);
                    }
                    printf("\n");

                    printf("Associated Data: ");
                    for (int i = 0; i < sizeof(ad) - 1; i++) {
                        printf("%02x", ad[i]);
                    }
                    printf("\n");

                    printf("Authentication Tag: ");
                    for (int i = 0; i < sizeof(tag); i++) {
                        printf("%02x", tag[i]);
                    }
                    printf("\n");

                    // Initialize ChaChaPoly again with same key
                    chachapoly_init(&ctx, key, 256);

                    int result = chachapoly_crypt(&ctx, nonce, ad, sizeof(ad) - 1,
                                                ciphertext, input_len,
                                                decrypted, tag, sizeof(tag), 0);

                    if (result == CHACHAPOLY_OK) {
                        decrypted[input_len] = '\0';
                        printf("Decryption successful!\n");
                        printf("Decrypted text: %s\n", decrypted);
                    } else {
                        printf("Authentication failed! Tag mismatch.\n");
                    }

                    ESP_LOGI(TAG, "Decryption attempt finished");
                    break;


            case 3:
                printf("Exiting demo...\n");
                ESP_LOGI(TAG, "Demo exited by user");
                return;

            default:
                printf("Invalid option. Try again.\n");
                break;
        }

        vTaskDelay(1000 / portTICK_PERIOD_MS);
    }
}

void app_main(void) {
    // Configure UART
    uart_config_t uart_config = {
        .baud_rate = 115200,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE
    };
    uart_param_config(UART_NUM_0, &uart_config);

    vTaskDelay(1000 / portTICK_PERIOD_MS); // Wait for serial monitor

    printf("\nESP32 ChaCha20-Poly1305 Interactive Demonstration\n");
    printf("Using UART for input/output\n");

    chachapoly_demo_interactive();
}





