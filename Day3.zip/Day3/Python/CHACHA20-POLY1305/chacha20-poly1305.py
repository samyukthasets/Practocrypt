#!/usr/bin/env python3
"""
RFC 8439 ChaCha20-Poly1305 Python reference matching C implementation.
"""

import struct
from sha3_256 import sha3_256
import sys, os

# ----------------------
# ChaCha20
# ----------------------

def rotl32(v, n):
    return ((v << n) & 0xffffffff) | (v >> (32 - n))

def quarter_round(s, a, b, c, d):
    s[a] = (s[a] + s[b]) & 0xffffffff; s[d] ^= s[a]; s[d] = rotl32(s[d],16)
    s[c] = (s[c] + s[d]) & 0xffffffff; s[b] ^= s[c]; s[b] = rotl32(s[b],12)
    s[a] = (s[a] + s[b]) & 0xffffffff; s[d] ^= s[a]; s[d] = rotl32(s[d],8)
    s[c] = (s[c] + s[d]) & 0xffffffff; s[b] ^= s[c]; s[b] = rotl32(s[b],7)

def chacha20_block(key, counter, nonce):
    const = b"expand 32-byte k"
    state = list(struct.unpack("<4I", const)) + \
            list(struct.unpack("<8I", key)) + \
            [counter] + list(struct.unpack("<3I", nonce))
    working = state.copy()
    for _ in range(10):
        # column rounds
        quarter_round(working,0,4,8,12)
        quarter_round(working,1,5,9,13)
        quarter_round(working,2,6,10,14)
        quarter_round(working,3,7,11,15)
        # diagonal round
        quarter_round(working,0,5,10,15)
        quarter_round(working,1,6,11,12)
        quarter_round(working,2,7,8,13)
        quarter_round(working,3,4,9,14)
    for i in range(16):
        working[i] = (working[i] + state[i]) & 0xffffffff
    return struct.pack("<16I", *working)

def chacha20_encrypt(key, counter, nonce, plaintext):
    out = bytearray()
    for i in range((len(plaintext)+63)//64):
        block = chacha20_block(key, counter+i, nonce)
        chunk = plaintext[i*64:(i+1)*64]
        out.extend(a^b for a,b in zip(chunk, block))
    return bytes(out)

# ----------------------
# Poly1305 matching C
# ----------------------

def poly1305_mac(msg, key):
    r = int.from_bytes(key[:16], "little")
    s = int.from_bytes(key[16:], "little")
    r &= 0x0ffffffc0ffffffc0ffffffc0fffffff
    p = (1 << 130) - 5
    acc = 0
    # Process 16-byte blocks
    for i in range(0,len(msg),16):
        block = msg[i:i+16]
        if len(block) < 16:
            block += b'\x01'  # append 0x01 to short block
        else:
            block += b'\x01'  # C-style 17-byte expansion
        n = int.from_bytes(block, "little")
        acc = (acc + n) * r % p
    # Serialize 128-bit tag (little-endian)
    tag = (acc + s) % (1<<128)
    return tag.to_bytes(16, "little")

def pad16(xlen):
    return (16 - (xlen %16)) %16

# ----------------------
# AEAD functions
# ----------------------

def aead_encrypt(key, nonce, plaintext, aad):
    assert len(key)==32 and len(nonce)==12
    otk = chacha20_block(key,0,nonce)[:32]
    ciphertext = chacha20_encrypt(key,1,nonce,plaintext)
    mac_data = aad + b'\x00'*pad16(len(aad))
    mac_data += ciphertext + b'\x00'*pad16(len(ciphertext))
    mac_data += struct.pack("<QQ", len(aad), len(ciphertext))
    tag = poly1305_mac(mac_data, otk)
    return ciphertext, tag

def aead_decrypt(key, nonce, ciphertext, aad, tag):
    otk = chacha20_block(key,0,nonce)[:32]
    mac_data = aad + b'\x00'*pad16(len(aad))
    mac_data += ciphertext + b'\x00'*pad16(len(ciphertext))
    mac_data += struct.pack("<QQ", len(aad), len(ciphertext))
    expected = poly1305_mac(mac_data, otk)
    if expected != tag:
        return None
    plaintext = chacha20_encrypt(key,1,nonce,ciphertext)
    return plaintext

if __name__ == "__main__":
    key = os.urandom(32)
    nonce = os.urandom(12)
    plaintext = sys.argv[1].encode()
    aad = sha3_256(sys.argv[2].encode())

    print("\t------------------")
    print("\tChacha20-Poly1305")
    print("\t------------------")
    print("\n\tPlain Text: ",sys.argv[1])
    print("\n\tKey: ",key.hex())
    print("\n\tNonce: ",nonce.hex())
    print("\n\tAssociated Data: ",aad.hex())

    ct, tag = aead_encrypt(key, nonce, plaintext, aad)
    print("\n\tCiphertext:", ct.hex())
    print("\n\tTag:", tag.hex())
    pt = aead_decrypt(key, nonce, ct, aad, tag)
    if pt is None:
        print("\n\tStatus: Decryption FAIL (tag mismatch)")
    else:
        print("\n\tStatus:Decryption OK:", pt.decode())
