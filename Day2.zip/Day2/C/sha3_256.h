#ifndef SHA3_256_H
#define SHA3_256_H

#define SHA3_256_RATE 136
#define SHA3_256_DIGEST 32

#include <stdint.h>
#include <stdio.h>

typedef struct {
    uint64_t state[25];
    uint8_t buffer[SHA3_256_RATE];
    size_t buffer_len;
} sha3_256_ctx;

void sha3_256(const uint8_t *in,size_t len,uint8_t out[SHA3_256_DIGEST]);


#endif