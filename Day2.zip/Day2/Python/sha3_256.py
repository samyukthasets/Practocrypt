# sha3_256_pure.py
# Pure Python SHA3-256 implementation (Keccak-f[1600])

from functools import reduce

# Rotation offsets
r = [[0, 36, 3, 41, 18],
     [1, 44,10, 45,  2],
     [62, 6,43, 15, 61],
     [28,55,25, 21, 56],
     [27,20,39,  8, 14]]

# Round constants
RC = [0x0000000000000001,0x0000000000008082,0x800000000000808A,0x8000000080008000,
      0x000000000000808B,0x0000000080000001,0x8000000080008081,0x8000000000008009,
      0x000000000000008A,0x0000000000000088,0x0000000080008009,0x000000008000000A,
      0x000000008000808B,0x800000000000008B,0x8000000000008089,0x8000000000008003,
      0x8000000000008002,0x8000000000000080,0x000000000000800A,0x800000008000000A,
      0x8000000080008081,0x8000000000008080,0x0000000080000001,0x8000000080008008]

# Rotate left 64-bit
def rotl(x, n):
    return ((x << n) | (x >> (64 - n))) & 0xFFFFFFFFFFFFFFFF

# Keccak-f[1600] permutation
def keccakf(st):
    for rnd in range(24):
        # Theta
        C = [st[x] ^ st[x+5] ^ st[x+10] ^ st[x+15] ^ st[x+20] for x in range(5)]
        D = [C[(x-1)%5] ^ rotl(C[(x+1)%5],1) for x in range(5)]
        st = [st[i] ^ D[i%5] for i in range(25)]
        # Rho and Pi
        B = [0]*25
        for x in range(5):
            for y in range(5):
                B[y + 5*((2*x+3*y)%5)] = rotl(st[x + 5*y], r[x][y])
        # Chi
        st = [B[i] ^ ((~B[(i//5*5 + (i%5+1)%5)]) & B[(i//5*5 + (i%5+2)%5)]) for i in range(25)]
        # Iota
        st[0] ^= RC[rnd]
    return st

# SHA3-256 parameters
rate = 1088 // 8  # 136 bytes
capacity = 512 // 8
output_len = 32

def sha3_256(data):
    # initialize state
    st = [0]*25
    # pad: SHA3 domain 0x06, pad10*1
    data = bytearray(data)
    data.append(0x06)
    while len(data) % rate != rate-1:
        data.append(0x00)
    data.append(0x80)

    # Absorb
    for block_start in range(0,len(data),rate):
        block = data[block_start:block_start+rate]
        for i in range(rate//8):
            lane = sum([block[i*8+j]<<(8*j) for j in range(8)])
            st[i] ^= lane
        st = keccakf(st)

    # Squeeze
    out = bytearray()
    while len(out) < output_len:
        for i in range(rate//8):
            lane = st[i]
            for b in range(8):
                if len(out) < output_len:
                    out.append((lane >> (8*b)) & 0xFF)
        # Next block if needed
        st = keccakf(st)
    return bytes(out)

# ----------- Test -----------
if __name__ == "__main__":
    import sys
    msg = sys.argv[1].encode()
    digest = sha3_256(msg)
    print("SHA3-256:", digest.hex())
