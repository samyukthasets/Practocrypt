import hashlib

def compute_sha3_hash(data, algorithm):
    """Compute SHA-3 hash for given data and algorithm."""
    if isinstance(data, str):
        data = data.encode('utf-8')
    
    hash_obj = hashlib.new(algorithm)
    hash_obj.update(data)
    return hash_obj.hexdigest()

def main():
    print("SHA-3 HASHING ALGORITHM VERIFICATION TOOL")
    
    # Get user input
    print("\nEnter the data you want to hash:")
    user_data = input("> ")
    
    # Display available algorithms
    print("\nAvailable SHA-3 Algorithms:")
    print("1. SHA3-256")
    print("2. SHA3-384")
    print("3. SHA3-512")
    print("4. All SHA-3 variants")
    
    choice = input("\nSelect algorithm (1-4): ")
    
    algorithms = {
        '1': 'sha3_256',
        '2': 'sha3_384',
        '3': 'sha3_512'
    }
    
    print("RESULTS")
    
    if choice == '4':
        # Compute all variants
        for name, algo in algorithms.items():
            hash_value = compute_sha3_hash(user_data, algo)
            variant_name = algo.replace('_', '-').upper()
            print(f"{variant_name}:")
            print(f"Hash: {hash_value}")
            print(f"Length: {len(hash_value) * 4} bits ({len(hash_value)} hex characters)")
    elif choice in algorithms:
        # Compute selected algorithm
        algo = algorithms[choice]
        hash_value = compute_sha3_hash(user_data, algo)
        variant_name = algo.replace('_', '-').upper()
        print(f"\n{variant_name}:")
        print(f"  Hash: {hash_value}")
        print(f"  Length: {len(hash_value) * 4} bits ({len(hash_value)} hex characters)")
    else:
        print("\nInvalid choice!")
        return
    
    # Verification option
    verify = input("\nDo you want to verify against an expected hash? (y/n): ")
    
    if verify.lower() == 'y':
        expected = input("Enter expected hash value: ")
        
        if choice == '4':
            print("\nPlease select which algorithm to verify:")
            verify_choice = input("Select algorithm (1-3): ")
            if verify_choice in algorithms:
                algo = algorithms[verify_choice]
                computed = compute_sha3_hash(user_data, algo)
            else:
                print("Invalid choice!")
                return
        else:
            algo = algorithms[choice]
            computed = compute_sha3_hash(user_data, algo)
        
        variant_name = algo.replace('_', '-').upper()
        print(f"\n{variant_name} Verification:")
        print(f"  Computed: {computed}")
        print(f"  Expected: {expected}")
        
        if computed == expected.lower():
            print(f"  ✓ MATCH - Hash verification successful!")
        else:
            print(f"  ✗ NO MATCH - Hash verification failed!")

if __name__ == "__main__":
    while True:
        main()
        again = input("\nRun again? (y/n): ")
        if again.lower() != 'y':
            print("\nGoodbye!")
            break
        print("\n")