#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_log.h"
#include "driver/uart.h"
#include "sha3.h"

static const char *TAG = "SHA3_DEMO";

#define MAX_INPUT_SIZE 1024
#define UART_NUM UART_NUM_0
#define BUF_SIZE 1024

// Function to convert bytes to hex string
void bytes_to_hex(const uint8_t* bytes, size_t len, char* hex_str) {
    for (size_t i = 0; i < len; i++) {
        sprintf(hex_str + (i * 2), "%02x", bytes[i]);
    }
    hex_str[len * 2] = '\0';
}

// Function to read a line from UART
int read_line(char* buffer, int max_len) {
    int len = 0;
    int data;
    
    while (len < max_len - 1) {
        data = getchar();
        if (data == EOF) {
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }
        
        if (data == '\r' || data == '\n') {
            if (len > 0) break;
            continue;
        }
        
        if (data == '\b' || data == 127) { // Backspace
            if (len > 0) {
                len--;
                printf("\b \b");
                fflush(stdout);
            }
            continue;
        }
        
        buffer[len++] = (char)data;
        printf("%c", data);
        fflush(stdout);
    }
    
    buffer[len] = '\0';
    printf("\n");
    return len;
}

// Function to display menu
void display_menu() {
    printf("\n=== ESP32 SHA3 Hash Calculator ===\n");
    printf("Select SHA3 variant:\n");
    printf("1. SHA3-256 (32-byte output)\n");
    printf("2. SHA3-384 (48-byte output)\n");
    printf("3. SHA3-512 (64-byte output)\n");
    printf("4. Exit\n");
    printf("Enter your choice (1-4): ");
}

// Function to get user input text
int get_input_text(char* buffer, int max_len) {
    printf("\nEnter text to hash (max %d chars): ", max_len - 1);
    return read_line(buffer, max_len);
}

// Function to perform SHA3-256
void perform_sha3_256(const char* input, int input_len) {
    uint8_t hash[32];
    char hex_output[65]; // 32 bytes * 2 + null terminator
    
    printf("\nProcessing with SHA3-256...\n");
    
    sha3_256(hash, (const uint8_t*)input, input_len);
    bytes_to_hex(hash, 32, hex_output);
    
    printf("Input: \"%s\"\n", input);
    printf("Input length: %d bytes\n", input_len);
    printf("SHA3-256: %s\n", hex_output);
}

// Function to perform SHA3-384
void perform_sha3_384(const char* input, int input_len) {
    uint8_t hash[48];
    char hex_output[97]; // 48 bytes * 2 + null terminator
    
    printf("\nProcessing with SHA3-384...\n");
    
    sha3_384(hash, (const uint8_t*)input, input_len);
    bytes_to_hex(hash, 48, hex_output);
    
    printf("Input: \"%s\"\n", input);
    printf("Input length: %d bytes\n", input_len);
    printf("SHA3-384: %s\n", hex_output);
}

// Function to perform SHA3-512
void perform_sha3_512(const char* input, int input_len) {
    uint8_t hash[64];
    char hex_output[129]; // 64 bytes * 2 + null terminator
    
    printf("\nProcessing with SHA3-512...\n");
    
    sha3_512(hash, (const uint8_t*)input, input_len);
    bytes_to_hex(hash, 64, hex_output);
    
    printf("Input: \"%s\"\n", input);
    printf("Input length: %d bytes\n", input_len);
    printf("SHA3-512: %s\n", hex_output);
}

// Function to demonstrate incremental API
void demonstrate_incremental_api(const char* input, int input_len) {
    printf("\n--- Demonstrating Incremental API ---\n");
    
    // SHA3-256 incremental example
    sha3_256incctx ctx256;
    uint8_t hash256[32];
    char hex256[65];
    
    sha3_256_inc_init(&ctx256);
    
    // Process input in chunks (simulating streaming)
    int chunk_size = 10;
    int processed = 0;
    
    printf("Processing input in chunks of %d bytes...\n", chunk_size);
    
    while (processed < input_len) {
        int remaining = input_len - processed;
        int current_chunk = (remaining < chunk_size) ? remaining : chunk_size;
        
        sha3_256_inc_absorb(&ctx256, (const uint8_t*)(input + processed), current_chunk);
        printf("Processed chunk: %d-%d bytes\n", processed, processed + current_chunk - 1);
        
        processed += current_chunk;
    }
    
    sha3_256_inc_finalize(hash256, &ctx256);
    bytes_to_hex(hash256, 32, hex256);
    
    printf("SHA3-256 (incremental): %s\n", hex256);
}

void app_main(void) {
    char input_buffer[MAX_INPUT_SIZE];
    char choice_buffer[10];
    int choice, input;
    int input_len;
    
    // Initialize UART
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    
    ESP_LOGI(TAG, "SHA3 Demo Starting...");
    
    printf("\n*** ESP32 SHA3 Hash Calculator ***\n");
    printf("This program demonstrates SHA3-256, SHA3-384, and SHA3-512 hashing.\n");
    
    while (1) {
        display_menu();
        
        if (read_line(choice_buffer, sizeof(choice_buffer)) <= 0) {
            continue;
        }
        
        choice = atoi(choice_buffer);
        
        switch (choice) {
            case 1: // SHA3-256
                input_len = get_input_text(input_buffer, MAX_INPUT_SIZE);
                if (input_len > 0) {
                    perform_sha3_256(input_buffer, input_len);
                    demonstrate_incremental_api(input_buffer, input_len);
                }
                break;
                
            case 2: // SHA3-384
                input_len = get_input_text(input_buffer, MAX_INPUT_SIZE);
                if (input_len > 0) {
                    perform_sha3_384(input_buffer, input_len);
                }
                break;
                
            case 3: // SHA3-512
                input_len = get_input_text(input_buffer, MAX_INPUT_SIZE);
                if (input_len > 0) {
                    perform_sha3_512(input_buffer, input_len);
                }
                break;
                
            case 4: // Exit
                printf("\nExiting SHA3 Demo. Goodbye!\n");
                vTaskDelay(pdMS_TO_TICKS(1000));
                esp_restart();
                break;
                
            default:
                printf("\nExiting ..........\n");
                return;
        }
    }
}