import hashlib

def compute_blake2s_hash(data, digest_size=32, key=None):
    """Compute BLAKE2s hash with various parameters."""
    if isinstance(data, str):
        data = data.encode('utf-8')
    
    if key and isinstance(key, str):
        key = key.encode('utf-8')
    
    hash_obj = hashlib.blake2s(
        data, 
        digest_size=digest_size,
        key=key if key else b'',
    )
    return hash_obj.hexdigest()

def main():
    print("BLAKE2s HASHING ALGORITHM VERIFICATION TOOL")
    
    # Get user input
    print("\nEnter the data you want to hash:")
    user_data = input("> ")
    
    print("\n1. 256-bit (32 bytes) - Default")
    print("2. Custom size")
    
    size_choice = input("\nSelect your choice: ")
    
    # Advanced options
    print("\nAdvanced Options (press Enter to skip)")
 
    use_key = input("Use a secret key? (y/n): ")
    key = None
    if use_key.lower() == 'y':
        key = input("Enter secret key: ")
    
    print("\nRESULTS")
    if size_choice == '1':
        # Compute all standard sizes
        size = 32
        hash_value = compute_blake2s_hash(user_data, size, key)
        print(f"BLAKE2s-{size * 8}:")
        print(f"{hash_value}")

    elif size_choice == '2':
        custom_size = int(input("\nEnter custom digest size (1-32 bytes): "))
        if 1 <= custom_size <= 32:
            hash_value = compute_blake2s_hash(user_data, custom_size, key)
            print(f"BLAKE2s-{custom_size * 8}:")
            print(f"{hash_value}")
        else:
            print("Invalid size! Must be between 1 and 32 bytes.")
            return
    else:
        print("\nInvalid choice!")
        return
    
    # Verification option
    verify = input("\nDo you want to verify against an expected hash? (y/n): ")
    
    if verify.lower() == 'y':
        expected = input("Enter expected hash value: ")
        if size_choice == '2':
            computed = compute_blake2s_hash(user_data, custom_size, key)
            size = custom_size
        else:
            size = 32
            computed = compute_blake2s_hash(user_data, size, key)
        
        print(f"\nBLAKE2s-{size * 8} Verification:")
        print(f"  Computed: {computed}")
        print(f"  Expected: {expected}")
        
        if computed == expected.lower():
            print(f"  ✓ MATCH - Hash verification successful!")
        else:
            print(f"  ✗ NO MATCH - Hash verification failed!")

if __name__ == "__main__":
    while True:
        main()
        again = input("\nRun again? (y/n): ")
        if again.lower() != 'y':
            print("\nGoodbye!")
            break
        print("\n")