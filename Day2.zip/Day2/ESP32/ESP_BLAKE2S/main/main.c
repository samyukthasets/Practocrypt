#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "blake2s.h"

#define TAG "BLAKE2S"
#define BUF_SIZE 1024
#define MAX__INPUT 512

// Function to convert hash output to hex string
void hash_to_hex(const uint8_t *hash, size_t len, char *output) {
    for (size_t i = 0; i < len; i++) {
        sprintf(output + (i * 2), "%02x", hash[i]);
    }
    output[len * 2] = '\0';
}

// Function to read line from UART
int read_line(char *buffer, size_t max_len) {
    int len = 0;
    int c;
    
    while (len < max_len - 1) {
        c = getchar();
        
        if (c == EOF) {
            vTaskDelay(10 / portTICK_PERIOD_MS);
            continue;
        }
        
        if (c == '\n' || c == '\r') {
            buffer[len] = '\0';
            return len;
        }
        
        if (c == 127 || c == 8) { // Backspace
            if (len > 0) {
                len--;
                printf("\b \b");
                fflush(stdout);
            }
            continue;
        }
        
        buffer[len++] = (char)c;
        putchar(c);
        fflush(stdout);
    }
    
    buffer[len] = '\0';
    return len;
}

void app_main(void) {
    char input_buffer[MAX__INPUT];
    char key_buffer[MAX__INPUT];
    uint8_t hash[32];
    char hex_output[65];
    int choice;
    size_t hash_len;
    
    // Configure UART
    uart_config_t uart_config = {
        .baud_rate = 115200,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE
    };
    uart_param_config(UART_NUM_0, &uart_config);
    
    ESP_LOGI(TAG, "BLAKE2s Hashing Demo");
    ESP_LOGI(TAG, "====================");
    
    while (1) {
        printf("\n\n--- BLAKE2s Hash Generator ---\n");
        printf("1. Hash text (no key)\n");
        printf("2. Hash text with key (HMAC)\n");
        printf("3. Custom hash length\n");
        printf("Select option (1-3): ");
        fflush(stdout);
        
        // Read choice
        char choice_buf[10];
        read_line(choice_buf, sizeof(choice_buf));
        choice = atoi(choice_buf);
        printf("\n");
        
        if (choice < 1 || choice > 3) {
            printf("Invalid option. Try again.\n");
            continue;
        }
        
        // Get input text
        printf("Enter text to hash: ");
        fflush(stdout);
        int input_len = read_line(input_buffer, sizeof(input_buffer));
        printf("\n");
        
        if (input_len == 0) {
            printf("Empty input. Try again.\n");
            continue;
        }
        
        switch (choice) {
            case 1: {
                // Simple hash with default 32-byte output
                hash_len = 32;
                int ret = blake2s(hash, hash_len, NULL, 0, input_buffer, input_len);
                
                if (ret == 0) {
                    hash_to_hex(hash, hash_len, hex_output);
                    printf("\nBLAKE2s Hash (256-bit):\n%s\n", hex_output);
                    ESP_LOGI(TAG, "Hash generated successfully");
                } else {
                    printf("Error generating hash\n");
                    ESP_LOGE(TAG, "Hash generation failed");
                }
                break;
            }
            
            case 2: {
                // Hash with key (HMAC-like)
                printf("Enter secret key: ");
                fflush(stdout);
                int key_len = read_line(key_buffer, sizeof(key_buffer));
                printf("\n");
                
                if (key_len == 0 || key_len > 32) {
                    printf("Invalid key length (must be 1-32 bytes)\n");
                    break;
                }
                
                hash_len = 32;
                int ret = blake2s(hash, hash_len, key_buffer, key_len, input_buffer, input_len);
                
                if (ret == 0) {
                    hash_to_hex(hash, hash_len, hex_output);
                    printf("\nBLAKE2s Keyed Hash (256-bit):\n%s\n", hex_output);
                    ESP_LOGI(TAG, "Keyed hash generated successfully");
                } else {
                    printf("Error generating keyed hash\n");
                    ESP_LOGE(TAG, "Keyed hash generation failed");
                }
                break;
            }
            
            case 3: {
                // Custom hash length
                printf("Enter hash length in bytes (1-32): ");
                fflush(stdout);
                char len_buf[10];
                read_line(len_buf, sizeof(len_buf));
                hash_len = atoi(len_buf);
                printf("\n");
                
                if (hash_len < 1 || hash_len > 32) {
                    printf("Invalid hash length (must be 1-32)\n");
                    break;
                }
                
                int ret = blake2s(hash, hash_len, NULL, 0, input_buffer, input_len);
                
                if (ret == 0) {
                    hash_to_hex(hash, hash_len, hex_output);
                    printf("\nBLAKE2s Hash (%zu-bit):\n%s\n", hash_len * 8, hex_output);
                    ESP_LOGI(TAG, "Custom length hash generated successfully");
                } else {
                    printf("Error generating hash\n");
                    ESP_LOGE(TAG, "Hash generation failed");
                }
                break;
            }
        }
        
        // Clear sensitive data
        memset(input_buffer, 0, sizeof(input_buffer));
        memset(key_buffer, 0, sizeof(key_buffer));
        memset(hash, 0, sizeof(hash));
        
        vTaskDelay(1000 / portTICK_PERIOD_MS);
    }
}