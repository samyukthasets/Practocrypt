#ifndef COMPACT_DISABLE_ED25519
#include "compact_ed25519.h"
#endif
#ifndef COMPACT_DISABLE_X25519
#include "compact_x25519.h"
#endif
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#if defined(_WIN32)
#include <windows.h>
#include <wincrypt.h>
#pragma comment(lib, "advapi32.lib")

int csprng_get_bytes(uint8_t *buf, size_t len) {
    HCRYPTPROV hProv;
    if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
        return -1;
    BOOL ok = CryptGenRandom(hProv, (DWORD)len, buf);
    CryptReleaseContext(hProv, 0);
    return ok ? 0 : -1;
}

#elif defined(__linux__) || defined(__APPLE__)
#include <fcntl.h>
#include <unistd.h>

int csprng_get_bytes(uint8_t *buf, size_t len) {
    int fd = open("/dev/urandom", O_RDONLY);
    if (fd < 0) return -1;
    size_t off = 0;
    while (off < len) {
        ssize_t r = read(fd, buf + off, len - off);
        if (r <= 0) { close(fd); return -1; }
        off += (size_t)r;
    }
    close(fd);
    return 0;
}
#else
#error "No secure RNG available on this platform."
#endif

static void print_hex(const char *label, const uint8_t *b, size_t len){
    printf("%s",label); for(size_t i=0;i<len;i++) printf("%02x",b[i]); printf("\n");
}

void main(){


    uint8_t seed1[X25519_KEY_SIZE];
    uint8_t seed2[X25519_KEY_SIZE];
    uint8_t priv1[X25519_KEY_SIZE];
    uint8_t pub1[X25519_KEY_SIZE];
    uint8_t priv2[X25519_KEY_SIZE];
    uint8_t pub2[X25519_KEY_SIZE];
    uint8_t shared1[X25519_SHARED_SIZE];
    uint8_t shared2[X25519_SHARED_SIZE];
    int r = 0;

    csprng_get_bytes(seed1,X25519_KEY_SIZE);
    csprng_get_bytes(seed2,X25519_KEY_SIZE);

  
    compact_x25519_keygen(priv1, pub1, seed1);
    compact_x25519_keygen(priv2, pub2, seed2);

    print_hex("Private Key Alice : ",priv1,X25519_KEY_SIZE);
    print_hex("Public Key Alice : ",pub1,X25519_KEY_SIZE);
    print_hex("\nPrivate Key Bob : ",priv2,X25519_KEY_SIZE);
    print_hex("Public Key Bob : ",pub2,X25519_KEY_SIZE);

    compact_x25519_shared(shared1, priv1, pub2);
    compact_x25519_shared(shared2, priv2, pub1);

    #ifndef COMPACT_DISABLE_X25519_DERIVE
    uint8_t derived[64];
    compact_x25519_derive_encryption_key(derived, sizeof(derived), shared1, pub1, pub2);
#endif

    if (memcmp(shared1, shared2, X25519_SHARED_SIZE) == 0) {
        printf("Success\n");
        print_hex("\nShared Secret (Alice) : ",shared1,X25519_SHARED_SIZE);
        print_hex("Shared Secret (Bob) : ",shared2,X25519_SHARED_SIZE);
        printf("\n");
    }
    else {
        printf("Fail\n");
     
    }


}

