This directory contains [Daniel Beer's (Public Domain) c25519 implementation](https://www.dlbeer.co.nz/oss/c25519.html),
with some minor adjustments to add define guards.

Version: 2017-10-05