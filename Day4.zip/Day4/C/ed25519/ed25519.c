
#ifndef COMPACT_DISABLE_ED25519
#include "compact_ed25519.h"
#endif
#ifndef COMPACT_DISABLE_X25519
#include "compact_x25519.h"
#endif
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#if defined(_WIN32)
#include <windows.h>
#include <wincrypt.h>
#pragma comment(lib, "advapi32.lib")

int csprng_get_bytes(uint8_t *buf, size_t len) {
    HCRYPTPROV hProv;
    if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
        return -1;
    BOOL ok = CryptGenRandom(hProv, (DWORD)len, buf);
    CryptReleaseContext(hProv, 0);
    return ok ? 0 : -1;
}

#elif defined(__linux__) || defined(__APPLE__)
#include <fcntl.h>
#include <unistd.h>

int csprng_get_bytes(uint8_t *buf, size_t len) {
    int fd = open("/dev/urandom", O_RDONLY);
    if (fd < 0) return -1;
    size_t off = 0;
    while (off < len) {
        ssize_t r = read(fd, buf + off, len - off);
        if (r <= 0) { close(fd); return -1; }
        off += (size_t)r;
    }
    close(fd);
    return 0;
}
#else
#error "No secure RNG available on this platform."
#endif

static void print_hex(const char *label, const uint8_t *b, size_t len){
    printf("%s",label); for(size_t i=0;i<len;i++) printf("%02x",b[i]); printf("\n");
}

static void print_sig(const char *label, const uint8_t *b, size_t len){
    printf("%s",label); for(int i=0;i<len;i++) printf("%s%02x", (i==len/2)?"\nS: ":"", b[i]); printf("\n");
}

int main(int argc, char **argv){
    uint8_t seed[ED25519_SEED_SIZE];

    printf("\n");
    csprng_get_bytes(seed,ED25519_SEED_SIZE);

    uint8_t sec[ED25519_PRIVATE_KEY_SIZE];
    uint8_t pub[ED25519_PUBLIC_KEY_SIZE];

    const char* message = argv[1];

    printf("Message : %s\n",message);

    print_hex("Private Key : ",seed,ED25519_SEED_SIZE);
    compact_ed25519_keygen(sec, pub, seed);
    print_hex("Public Key : ",pub,ED25519_PUBLIC_KEY_SIZE);

    printf("\n");

    uint8_t sig[ED25519_SIGNATURE_SIZE];
    compact_ed25519_sign(sig, sec, (uint8_t *)message, strlen(message));

    if (!compact_ed25519_verify(sig, pub, (uint8_t *)message, strlen(message))) {
        printf("Failed normal signature\n");
        return -1;
    }
    else {
        printf("Success\n");
        print_sig("R : ",sig,ED25519_SIGNATURE_SIZE);
        printf("\n");
    }
    return 0;
}