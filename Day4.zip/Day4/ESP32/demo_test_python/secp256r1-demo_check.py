from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature
from hashlib import sha3_256

# ==============================
# Replace data with your ESP32 outputs
# ==============================
alice_pub_hex = "e59145ecad875dc62360d1d28ca27938e835551054e3d7b7be0bca4352dd804af5695e584b759052609afeb812b4ed05307d6b94ecf0a10c32403f7a79208b6d"
signature_hex  = "b5195951c23d8dae558a5cde0a4d782769e0383963c0b9883c1a098324f623388ad7b134beba4e8a45a45260ca3d82e2d3d8ec55479dc92edd66aea72016eebe"
message = b"hii gm"

bob_priv_hex = "945c3dd14cddcd198b2d1ed92f2d7c1bbc81a7d83f9a8bb7ba832e6f915177b2"

# ==============================
# Convert from hex
# ==============================
alice_pub_bytes = bytes.fromhex(alice_pub_hex)
signature_bytes = bytes.fromhex(signature_hex)
bob_priv_int = int.from_bytes(bytes.fromhex(bob_priv_hex), "big")

# ==============================
# Verify Message Hash
# ==============================
hash_val = sha3_256(message).digest()
print("Derived Hash of Message (SHA3-256):", hash_val.hex())

# ==============================
# Load Alice's Public Key
# ==============================
x = int.from_bytes(alice_pub_bytes[:32], "big")
y = int.from_bytes(alice_pub_bytes[32:], "big")

alice_pub_key = ec.EllipticCurvePublicNumbers(x, y, ec.SECP256R1()).public_key(default_backend())

# ==============================
# Convert raw r||s signature -> DER format
# ==============================
r = int.from_bytes(signature_bytes[:32], "big")
s = int.from_bytes(signature_bytes[32:], "big")
signature_der = encode_dss_signature(r, s)

# ==============================
# Verify Alice's signature
# ==============================
try:
    alice_pub_key.verify(signature_der, message, ec.ECDSA(hashes.SHA3_256()))
    print("✅ Signature verified successfully!")
except InvalidSignature:
    print("❌ Invalid signature")

# ==============================
# ECDH (Diffie–Hellman)
# ==============================
bob_priv_key = ec.derive_private_key(bob_priv_int, ec.SECP256R1(), default_backend())
shared_secret = bob_priv_key.exchange(ec.ECDH(), alice_pub_key)

print("Shared Secret (ECDH):", shared_secret.hex())

