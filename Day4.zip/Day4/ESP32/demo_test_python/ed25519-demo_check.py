from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.exceptions import InvalidSignature

# ==============================
# Replace data with your ESP32 outputs
# ==============================
public_key_bytes = bytes.fromhex(
    "9910FC7F2C5213223271A35F0AAAC42D7B61264E407C3FD47E458D3DBE8E616E"
)  # 32-byte public key

message = b"hii hello"  # The same message that was signed

signature_bytes = bytes.fromhex(
    "A0279D2D2C30EC4A7FA4C1A6EDD4DB7650E8C0E72A7199DCCF402BB62C84FABE34C27AB340882E6BD19D073DC92861EA7955816CBAE56065EF7D8D411C8F320A" 
)  # 64-byte signature

# Load the public key
public_key = ed25519.Ed25519PublicKey.from_public_bytes(public_key_bytes)

# ==============================
# Verify the signature
# ==============================
try:
    public_key.verify(signature_bytes, message)
    print("✅ Signature is valid")
except InvalidSignature:
    print("❌ Signature is invalid")