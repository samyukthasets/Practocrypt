from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives import serialization

def print_hex(label, data: bytes):
    print(f"{label}: {data.hex()}")

# ==============================
# Replace data with your ESP32 outputs
# ==============================
alice_priv_hex = "d004d4a349128978c4f2de9532702afae103028c30d5ab3e3812d5653e3de440"
alice_pub_hex  = "7b4e9fe2fa158559ec5b6c1619b524313c8420b3b8599c9a4a13e8f87d954f3e"

bob_priv_hex = "40681805237fd6f2055803f0978a6fb90e6f7dfd8c9737d14a7b9150662cbb7c"
bob_pub_hex  = "3fa127b1382e94ab16483d71a20fa28636134c7039289d6c2f42007ff354ad15"

# ==============================
# Convert to bytes
# ==============================
alice_priv_bytes = bytes.fromhex(alice_priv_hex)
alice_pub_bytes  = bytes.fromhex(alice_pub_hex)

bob_priv_bytes = bytes.fromhex(bob_priv_hex)
bob_pub_bytes  = bytes.fromhex(bob_pub_hex)

# ==============================
# Build key objects
# ==============================
alice_priv = x25519.X25519PrivateKey.from_private_bytes(alice_priv_bytes)
bob_priv   = x25519.X25519PrivateKey.from_private_bytes(bob_priv_bytes)

alice_pub  = x25519.X25519PublicKey.from_public_bytes(alice_pub_bytes)
bob_pub    = x25519.X25519PublicKey.from_public_bytes(bob_pub_bytes)

# ==============================
# Validate Alice's key pair
# ==============================
derived_alice_pub = alice_priv.public_key().public_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PublicFormat.Raw
)
print_hex("Alice Public (given) ", alice_pub_bytes)
print_hex("Alice Public (derived)", derived_alice_pub)
if derived_alice_pub == alice_pub_bytes:
    print("✅ Alice's key pair is valid")
else:
    print("❌ Alice's key pair is INVALID")

# ==============================
# Validate Bob's key pair
# ==============================
derived_bob_pub = bob_priv.public_key().public_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PublicFormat.Raw
)
print_hex("Bob Public (given) ", bob_pub_bytes)
print_hex("Bob Public (derived)", derived_bob_pub)
if derived_bob_pub == bob_pub_bytes:
    print("✅ Bob's key pair is valid")
else:
    print("❌ Bob's key pair is INVALID")

# ==============================
# Compute shared secrets
# ==============================
shared_alice = alice_priv.exchange(bob_pub)
shared_bob   = bob_priv.exchange(alice_pub)

print_hex("Shared Secret (Alice)", shared_alice)
print_hex("Shared Secret (Bob)  ", shared_bob)

if shared_alice == shared_bob:
    print("✅ Shared secret matches! Secure channel established")
else:
    print("❌ Shared secret mismatch!")
