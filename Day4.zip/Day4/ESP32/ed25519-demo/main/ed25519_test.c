#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_log.h"
#include "esp_heap_caps.h"
#include "esp_random.h"

#include "src/ed25519.h"
#include "src/ge.h"
#include "src/sc.h"

#define MAX_MSG_LEN 256
#define MAX_INPUT_SIZE 128

// static const char *TAG = "ED25519_DEMO";

// Global Ed25519 keys
unsigned char alice_pub[32], alice_priv[64];
unsigned char bob_pub[32], bob_priv[64];
unsigned char shared_secret_alice[32], shared_secret_bob[32];
unsigned char last_signature[64];
char last_message[MAX_MSG_LEN];
int last_msg_len = 0;
int keys_generated = 0;
unsigned char p1[32], p2[32];

// Helper: Print hex
void print_hex(const char *label, const unsigned char *data, size_t len) {
    printf("%s: ", label);
    for (size_t i = 0; i < len; i++) printf("%02X", data[i]);
    printf("\n");
}

// Helper: Read line from UART
int read_line(char *buffer, int max_len) {
    int len = 0;
    int ch;
    while (len < max_len - 1) {
        ch = getchar();
        if (ch == EOF) {
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }
        if (ch == '\r' || ch == '\n') {
            if (len > 0) break;
            continue;
        }
        if (ch == '\b' || ch == 127) {
            if (len > 0) {
                len--;
                printf("\b \b");
                fflush(stdout);
            }
            continue;
        }
        buffer[len++] = (char)ch;
        printf("%c", ch);
        fflush(stdout);
    }
    buffer[len] = '\0';
    printf("\n");
    return len;
}

// Menu display
void display_menu() {
    printf("\n===========================================\n");
    printf("   ESP32 Ed25519 Demo\n");
    printf("===========================================\n");
    printf("1. Generate Alice & Bob Keys\n");
    printf("2. Sign a Message with Alice's Private Key\n");
    printf("3. Verify Signature with Alice's Public Key\n");
    printf("4. Key Exchange (Shared Secret)\n");
    printf("5. View Keys\n");
    printf("6. Exit\n");
    printf("Enter choice: ");
}

// Generate keys
void generate_keys() {
    unsigned char seed[32];

    printf("\n--- Generating Ed25519 Key Pairs ---\n");

    // Alice
    esp_fill_random(seed, 32);
    ed25519_create_keypair(alice_pub, alice_priv, seed);
    printf("\n✅ Alice's Keys Generated\n");
    print_hex("Alice Private Key", seed, 32);
    print_hex("Alice Public Key ", alice_pub, 32);
    memcpy(p1, seed, 32);

    // Bob
    esp_fill_random(seed, 32);
    ed25519_create_keypair(bob_pub, bob_priv, seed);
    printf("\n✅ Bob's Keys Generated\n");
    print_hex("Bob Private Key", seed, 32);
    print_hex("Bob Public Key ", bob_pub, 32);
    memcpy(p2, seed, 32);

    keys_generated = 1;
}

// Sign a message
void sign_message() {
    if (!keys_generated) return;

    char message[MAX_MSG_LEN];
    printf("\nEnter message to sign: ");
    int len = read_line(message, MAX_MSG_LEN);
    if (len <= 0) return;

    // Sign the message
    ed25519_sign(last_signature, (unsigned char*)message, len, alice_pub, alice_priv);

    // Store message globally
    memcpy(last_message, message, len);
    last_msg_len = len;
    last_message[len] = '\0';   // <--- null terminate

    printf("\n✅ Message signed successfully!\n");
    print_hex("Message", (unsigned char*)message, len);
    print_hex("Signature", last_signature, 64);
}

// Verify a signature
void verify_signature() {
    if (!keys_generated) {
        printf("\n❌ Keys not generated yet! Please select option 1.\n");
        return;
    }
    if (last_msg_len == 0) {
        printf("\n❌ No message signed yet! Please select option 2.\n");
        return;
    }

    char choice[4];
    printf("\nVerify last signed message? (y/n): ");
    if (read_line(choice, sizeof(choice)) <= 0) return;

    char message[MAX_MSG_LEN];
    unsigned char signature[64];

    if (choice[0] == 'y' || choice[0] == 'Y') {
    memcpy(message, last_message, last_msg_len);
    int msg_len = last_msg_len;
    memcpy(signature, last_signature, 64);

    if (ed25519_verify(signature, (unsigned char*)message, msg_len, alice_pub)) {
        printf("\n✅ Signature verification PASSED!\n");
    } else {
        printf("\n❌ Signature verification FAILED!\n");
    }
}
}

// Key exchange (compute shared secret)
void key_exchange() {
    if (!keys_generated) {
        printf("\n❌ Keys not generated yet! Please select option 1.\n");
        return;
    }

    ed25519_key_exchange(shared_secret_alice, bob_pub, alice_priv);
    ed25519_key_exchange(shared_secret_bob, alice_pub, bob_priv);

    print_hex("Shared Secret (Alice)", shared_secret_alice, 32);
    print_hex("Shared Secret (Bob)  ", shared_secret_bob, 32);

    if (memcmp(shared_secret_alice, shared_secret_bob, 32) == 0) {
        printf("\n✅ Key exchange successful: both secrets match!\n");
    } else {
        printf("\n❌ Key exchange failed: secrets do not match!\n");
    }
}

// View keys
void view_keys() {
    if (!keys_generated) {
        printf("\n❌ Keys not generated yet! Please select option 1.\n");
        return;
    }
    printf("\n--- Current Key Information ---\n");
    print_hex("Alice Private Key", p1, 32);
    print_hex("Alice Public Key ", alice_pub, 32);
    print_hex("Bob Private Key  ", p2, 32);
    print_hex("Bob Public Key   ", bob_pub, 32);
}

// Interactive task
void ed25519_demo_task(void *pvParameters) {
    char choice_buffer[10];
    int choice;

    while (1) {
        display_menu();
        if (read_line(choice_buffer, sizeof(choice_buffer)) <= 0) continue;
        choice = atoi(choice_buffer);

        switch (choice) {
            case 1: generate_keys(); break;
            case 2: sign_message(); break;
            case 3: verify_signature(); break;
            case 4: key_exchange(); break;
            case 5: view_keys(); break;
            case 6:
                printf("\n✅ Exiting demo. Restarting...\n");
                vTaskDelay(pdMS_TO_TICKS(1000));
                esp_restart();
                break;
            default:
                printf("\n❌ Invalid choice. Please select 1-6.\n");
                break;
        }

        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

void app_main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);

    printf("\nStarting ESP32 Ed25519 Interactive Demo...\n");

    xTaskCreate(ed25519_demo_task, "ed25519_demo", 8192, NULL, 5, NULL);

    while (1) vTaskDelay(pdMS_TO_TICKS(1000));
}
