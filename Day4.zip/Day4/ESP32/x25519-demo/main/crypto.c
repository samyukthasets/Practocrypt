#include "crypto.h"

void crypto_zero(void *dest, size_t len) {
    volatile uint8_t *p = (uint8_t *)dest;
    while (len--) *p++ = 0;
}

bool crypto_equal(const void *a, const void *b, size_t size) {
    const uint8_t *pa = (const uint8_t *)a;
    const uint8_t *pb = (const uint8_t *)b;
    uint8_t diff = 0;
    while (size--) diff |= *pa++ ^ *pb++;
    return diff == 0;
}