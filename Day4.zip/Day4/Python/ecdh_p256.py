#!/usr/bin/env python3
# pure-python ECDH & ECDSA on NIST P-256 (secp256r1)
# - No external libs
# - Correct curve parameters (verified)
# - Simple double-and-add scalar multiplication (correct)
# - RFC6979 deterministic k
# - Prints diagnostics for debugging / verification

from __future__ import annotations
import hashlib, hmac, secrets
from typing import Optional, Tuple
import sys, os

# ---- Curve parameters: secp256r1 (NIST P-256) ----
p = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
a = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFC  # p - 3
b = 0x5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B
Gx = 0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296
Gy = 0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5  # fixed
n  = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
h  = 1

Point = Optional[Tuple[int, int]]

# ---- Basic helpers ----
def mod_inv(x: int, m: int) -> int:
    return pow(x % m, -1, m)

def int_to_bytes(x: int, length: int = 32) -> bytes:
    return x.to_bytes(length, "big")

def bytes_to_int(b: bytes) -> int:
    return int.from_bytes(b, "big")

# ---- Point operations (affine) ----
def is_on_curve(P: Point) -> bool:
    if P is None: return True
    x, y = P
    return (y * y - (x * x * x + a * x + b)) % p == 0

def point_neg(P: Point) -> Point:
    if P is None: return None
    x, y = P
    return (x, (-y) % p)

def point_add(P: Point, Q: Point) -> Point:
    if P is None: return Q
    if Q is None: return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2:
        if (y1 + y2) % p == 0:
            return None
        return point_double(P)
    lam = ((y2 - y1) * mod_inv(x2 - x1, p)) % p
    x3 = (lam * lam - x1 - x2) % p
    y3 = (lam * (x1 - x3) - y1) % p
    return (x3, y3)

def point_double(P: Point) -> Point:
    if P is None: return None
    x1, y1 = P
    if y1 == 0:
        return None
    lam = ((3 * x1 * x1 + a) * mod_inv(2 * y1, p)) % p
    x3 = (lam * lam - 2 * x1) % p
    y3 = (lam * (x1 - x3) - y1) % p
    return (x3, y3)

def scalar_mult(k: int, P: Point) -> Point:
    """Simple binary double-and-add scalar multiplication (correct and easy to verify)."""
    if P is None or k % n == 0:
        return None
    k = k % n
    Q: Point = None
    R: Point = P
    while k > 0:
        if k & 1:
            Q = point_add(Q, R)
        R = point_double(R)
        k >>= 1
    return Q

# ---- Key generation ----
def generate_private_key() -> int:
    while True:
        d = secrets.randbelow(n)
        if 1 <= d < n:
            return d

def private_to_public(d: int) -> Tuple[int,int]:
    Q = scalar_mult(d, (Gx, Gy))
    if Q is None:
        raise ValueError("Generated public point is point at infinity")
    return Q

# ---- ECDH (raw x-coordinate) ----
def ecdh_shared_secret(priv: int, peer_pub: Tuple[int,int]) -> bytes:
    S = scalar_mult(priv, peer_pub)
    if S is None:
        raise ValueError("Invalid shared secret (point at infinity)")
    x, y = S
    return int_to_bytes(x % p, 32)

# ---- RFC6979 deterministic k helpers ----
def bits2int(b: bytes) -> int:
    qlen = n.bit_length()
    blen = len(b) * 8
    i = bytes_to_int(b)
    if blen > qlen:
        i >>= (blen - qlen)
    return i

def int2octets(x: int) -> bytes:
    return int_to_bytes(x, 32)

def bits2octets(b: bytes) -> bytes:
    z1 = bits2int(b)
    z2 = z1 - n if z1 >= n else z1
    return int2octets(z2)

def rfc6979_generate_k(msg_hash: bytes, priv: int) -> int:
    V = b'\x01' * 32
    K = b'\x00' * 32
    bx = int2octets(priv) + bits2octets(msg_hash)
    K = hmac.new(K, V + b'\x00' + bx, hashlib.sha256).digest()
    V = hmac.new(K, V, hashlib.sha256).digest()
    K = hmac.new(K, V + b'\x01' + bx, hashlib.sha256).digest()
    V = hmac.new(K, V, hashlib.sha256).digest()
    while True:
        T = b''
        while len(T) < 32:
            V = hmac.new(K, V, hashlib.sha256).digest()
            T += V
        k = bits2int(T)
        if 1 <= k < n:
            return k
        K = hmac.new(K, V + b'\x00', hashlib.sha256).digest()
        V = hmac.new(K, V, hashlib.sha256).digest()

# ---- ECDSA sign/verify ----
def ecdsa_sign(msg: bytes, priv: int) -> Tuple[int,int]:
    h = hashlib.sha256(msg).digest()
    e = bits2int(h)
    while True:
        k = rfc6979_generate_k(h, priv)
        R = scalar_mult(k, (Gx, Gy))
        if R is None:
            continue
        r = R[0] % n
        if r == 0:
            continue
        s = (mod_inv(k, n) * (e + r * priv)) % n
        if s == 0:
            continue
        # canonicalize s to lower half of n (optional but common)
        if s > n // 2:
            s = n - s
        return (r, s)

def ecdsa_verify(msg: bytes, pub: Tuple[int,int], sig: Tuple[int,int]) -> bool:
    r, s = sig
    if not (1 <= r < n and 1 <= s < n):
        return False
    h = hashlib.sha256(msg).digest()
    e = bits2int(h)
    w = mod_inv(s, n)
    u1 = (e * w) % n
    u2 = (r * w) % n
    P = point_add(scalar_mult(u1, (Gx, Gy)), scalar_mult(u2, pub))
    if P is None:
        return False
    xP = P[0] % n
    return xP == r

# ---- DER encode/decode helpers (optional) ----
def der_encode_signature(r: int, s: int) -> bytes:
    def int_to_bytes_no_leading(x: int) -> bytes:
        b = int_to_bytes(x, (x.bit_length() + 7) // 8 or 1)
        if b[0] & 0x80:
            b = b'\x00' + b
        return b
    rb = int_to_bytes_no_leading(r)
    sb = int_to_bytes_no_leading(s)
    seq = b'\x02' + bytes([len(rb)]) + rb + b'\x02' + bytes([len(sb)]) + sb
    return b'\x30' + bytes([len(seq)]) + seq

def der_decode_signature(der: bytes) -> Tuple[int,int]:
    if der[0] != 0x30:
        raise ValueError("DER: not a sequence")
    idx = 2
    if der[idx] != 0x02:
        raise ValueError("DER: first int tag missing")
    lr = der[idx+1]
    r = bytes_to_int(der[idx+2:idx+2+lr])
    idx = idx+2+lr
    if der[idx] != 0x02:
        raise ValueError("DER: second int tag missing")
    ls = der[idx+1]
    s = bytes_to_int(der[idx+2:idx+2+ls])
    return (r, s)

# ---- Utilities ----
def pubkey_to_bytes_uncompressed(pub: Tuple[int,int]) -> bytes:
    x,y = pub
    return b'\x04' + int_to_bytes(x,32) + int_to_bytes(y,32)

def bytes_to_pubkey_uncompressed(b: bytes) -> Tuple[int,int]:
    if b[0] != 4 or len(b) != 65:
        raise ValueError("Invalid uncompressed public key")
    x = bytes_to_int(b[1:33])
    y = bytes_to_int(b[33:65])
    return (x,y)

# ---- Self-test with diagnostics ----
def _ecdh_run():
    # generate keys
    sk = int(os.urandom(32).hex(),16)
    pk = private_to_public(sk)
    print("\nAlice's Private key d:", hex(sk))
    print("Alice's Public key Qx:", hex(pk[0]))
    print("Alice's Public key Qy:", hex(pk[1]))
    print("Alice's Public Key is on the curve ?:", is_on_curve(pk))

    sk2 = int(os.urandom(32).hex(),16)
    pk2 = private_to_public(sk2)
    print("\n\nBob's Private key d:", hex(sk2))
    print("Bob's Public key Qx:", hex(pk2[0]))
    print("Bob's Public key Qy:", hex(pk2[1]))
    print("Bob's Public Key is on the curve ?:", is_on_curve(pk2))

    ss1 = ecdh_shared_secret(sk, pk2)
    ss2 = ecdh_shared_secret(sk2, pk)
    print("\nECDH equal", ss1 == ss2)
    print("\nShared secret SS1 (hex):", ss1.hex())
    print("Shared secret SS2 (hex):", ss2.hex())

if __name__ == "__main__":
    _ecdh_run()
