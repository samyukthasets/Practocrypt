from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature
from cryptography.hazmat.primitives import hashes
from cryptography.exceptions import InvalidSignature

import os, sys

# Example: 32-byte X and Y coordinates (replace with your actual values)

x_bytes = bytes.fromhex("3d4133ce55b3799f7af596c822079ee712ed71780c5526ebe759c566337945a4")
y_bytes = bytes.fromhex("10cddfede55e7c40e2bd2a0253d0ab4d1185e130903b076a2a94ef52af696aeb")

# Convert bytes to integers
x_int = int.from_bytes(x_bytes, "big")
y_int = int.from_bytes(y_bytes, "big")

# Create an EllipticCurvePublicNumbers object
public_numbers = ec.EllipticCurvePublicNumbers(x_int, y_int, ec.SECP256R1())

# Construct the public key
public_key = public_numbers.public_key()

# Message that was signed
message = sys.argv[1].encode()



# Signature: raw r||s concatenated (64 bytes)
sig_bytes = bytes.fromhex(
    "a12ac6b140531a348344c265eae69c7734a2a98bd5de9044dcbe6ef51d4d6ea9"  # r
    "78485edbe9d48f7cf6bb5dd100a05b3e77c556f8dfff6e2f0412f58091e8b6aa"  # s
)
# Convert raw r||s to DER
r = int.from_bytes(sig_bytes[:32], "big")
s = int.from_bytes(sig_bytes[32:], "big")
der_signature = encode_dss_signature(r, s)

# Verify signature
try:
    public_key.verify(der_signature, message, ec.ECDSA(hashes.SHA256()))
    print("Signature is valid")
except InvalidSignature:
    print("Signature is invalid")