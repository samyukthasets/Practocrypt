from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization
import sys
def verify_eddsa_signature(public_key_pem, message, signature):
    """
    Verifies an EDDSA signature

    :param public_key_pem: The public key (in PEM format, as bytes).
    :param message: The message to verify (in bytes).
    :param signature: The EDDSA signature to verify (in bytes).
    :return: True if the signature is valid, False otherwise.
    """
    # Load the public key from PEM format
    public_key = serialization.load_pem_public_key(public_key_pem)

    # Verify the signature using the public key
    try:
        public_key.verify(signature, message)
        return True
    except Exception as e:
        print(f"Signature verification failed: {e}")
        return False

if __name__ == "__main__":
    # Example message
    message = sys.argv[1]
    
    public_key_bytes = bytes.fromhex("afc68de00d657b8388a13ac96e21f4d782f13875ed1f328817eb0be30215e061")
    public_key = ed25519.Ed25519PublicKey.from_public_bytes(public_key_bytes)

    public_key_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    r = bytes.fromhex("f9b2ab96ae2ac6d684139873c42c2a382e300ca47852282b95caee6dd32c2ea4")
    s = bytes.fromhex("c20d71102727b1b75c21abd51b3a150804ba83cb3be52bd88417576d0a273807")

    signature = r+s

    # Verify the signature using the public key
    is_valid = verify_eddsa_signature(public_key_pem, message, signature)

    print(f"Signature valid: {is_valid}")
