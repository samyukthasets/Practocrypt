/*
 * sha3-256.c
 *
 * Correct self-contained SHA3-256 (Keccak-f[1600]) implementation.
 * Little-endian lane packing.
 * Produces correct hash for known test vectors.
 *
 * Compile: gcc sha3-256.c -o sha3-256
 * Run: ./sha3-256
 */


#include <string.h>

/* Include the sha3_256  header file */
#include "seed_expander.h"


/* Rotation offsets for Keccak-f[1600] */
static const int r[5][5] = {
    { 0, 36, 3, 41, 18 },
    { 1, 44,10, 45, 2 },
    {62, 6,43, 15,61 },
    {28,55,25, 21,56 },
    {27,20,39, 8,14 }
};

/* Round constants */
static const uint64_t RC[24] = {
    0x0000000000000001ULL,0x0000000000008082ULL,
    0x800000000000808aULL,0x8000000080008000ULL,
    0x000000000000808bULL,0x0000000080000001ULL,
    0x8000000080008081ULL,0x8000000000008009ULL,
    0x000000000000008aULL,0x0000000000000088ULL,
    0x0000000080008009ULL,0x000000008000000aULL,
    0x000000008000808bULL,0x800000000000008bULL,
    0x8000000000008089ULL,0x8000000000008003ULL,
    0x8000000000008002ULL,0x8000000000000080ULL,
    0x000000000000800aULL,0x800000008000000aULL,
    0x8000000080008081ULL,0x8000000000008080ULL,
    0x0000000080000001ULL,0x8000000080008008ULL
};

/* Rotate left 64-bit */
static inline uint64_t rotl(uint64_t x,int s){ return (x << s)|(x >> (64-s)); }

/* Keccak-f[1600] permutation */
static void keccakf(uint64_t st[25]){
    int x,y,round;
    for(round=0;round<24;round++){
        uint64_t C[5],D[5];
        for(x=0;x<5;x++)
            C[x]=st[x]^st[x+5]^st[x+10]^st[x+15]^st[x+20];
        for(x=0;x<5;x++)
            D[x]=C[(x+4)%5]^rotl(C[(x+1)%5],1);
        for(x=0;x<5;x++)
            for(y=0;y<5;y++)
                st[x+5*y]^=D[x];
        uint64_t B[25];
        for(x=0;x<5;x++)
            for(y=0;y<5;y++)
                B[y+5*((2*x+3*y)%5)] = rotl(st[x+5*y],r[x][y]);
        for(x=0;x<5;x++)
            for(y=0;y<5;y++)
                st[x+5*y] = B[x+5*y] ^ ((~B[(x+1)%5 + 5*y]) & B[(x+2)%5 +5*y]);
        st[0]^=RC[round];
    }
}

/* Initialize context */
static void sha3_256_init(sha3_256_ctx *ctx){
    memset(ctx,0,sizeof(*ctx));
    ctx->buffer_len=0;
}

/* Absorb data */
static void sha3_256_update(sha3_256_ctx *ctx,const uint8_t *in,size_t len){
    size_t i=0;
    while(len>0){
        size_t to_copy = SHA3_256_RATE - ctx->buffer_len;
        if(to_copy>len) to_copy=len;
        memcpy(ctx->buffer+ctx->buffer_len,in+i,to_copy);
        ctx->buffer_len+=to_copy;
        i+=to_copy;
        len-=to_copy;
        if(ctx->buffer_len==SHA3_256_RATE){
            for(int j=0;j<17;j++){
                uint64_t lane=0;
                for(int b=0;b<8;b++)
                    lane|=(uint64_t)ctx->buffer[j*8+b]<<(8*b);
                ctx->state[j]^=lane;
            }
            keccakf(ctx->state);
            ctx->buffer_len=0;
        }
    }
}

/* Finalize and squeeze output */
static void sha3_256_final(sha3_256_ctx *ctx,uint8_t out[SHA3_256_DIGEST]){
    /* pad10*1 with SHA-3 domain 0x06 */
    ctx->buffer[ctx->buffer_len++] = 0x06;
    memset(ctx->buffer+ctx->buffer_len,0,SHA3_256_RATE-ctx->buffer_len);
    ctx->buffer[SHA3_256_RATE-1]|=0x80;
    for(int j=0;j<17;j++){
        uint64_t lane=0;
        for(int b=0;b<8;b++)
            lane|=(uint64_t)ctx->buffer[j*8+b]<<(8*b);
        ctx->state[j]^=lane;
    }
    keccakf(ctx->state);
    /* squeeze first 32 bytes */
    for(int i=0;i<SHA3_256_DIGEST;i++){
        out[i] = ((uint8_t*)ctx->state)[i];
    }
}

/* One-shot convenience */
void sha3_256(const uint8_t *in,size_t len,uint8_t out[SHA3_256_DIGEST]){
    sha3_256_ctx ctx;
    sha3_256_init(&ctx);
    sha3_256_update(&ctx,in,len);
    sha3_256_final(&ctx,out);
}

/* print hex helper */
static void print_hex(const uint8_t *b,int n){for(int i=0;i<n;i++)printf("%02x",b[i]);printf("\n");}

/* Test main */
// int main(){
//     const char *msg="SPCO2025-102";
//     uint8_t hash[SHA3_256_DIGEST];
//     sha3_256((const uint8_t*)msg,strlen(msg),hash);
//     printf("Input: %s\nSHA3-256: ",msg);
//     print_hex(hash,SHA3_256_DIGEST);
//     return 0;
// }
