from seed_expander import sha3_256

# AES S-box (same as your original)
s_box = [
 0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
 0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
 0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
 0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
 0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
 0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
 0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
 0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
 0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
 0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
 0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
 0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
 0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
 0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
 0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
 0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
]

Rcon = [0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1B,0x36]

def xtime(a): return ((a << 1) ^ 0x1B) & 0xFF if (a & 0x80) else (a << 1)

def mix_single_column(a):
    t = a[0] ^ a[1] ^ a[2] ^ a[3]
    u = a[0]
    a[0] ^= t ^ xtime(a[0] ^ a[1])
    a[1] ^= t ^ xtime(a[1] ^ a[2])
    a[2] ^= t ^ xtime(a[2] ^ a[3])
    a[3] ^= t ^ xtime(a[3] ^ u)
    return a

def mix_columns(state):
    new_state = state[:]
    for i in range(4):
        col = state[i*4:i*4+4]
        col = mix_single_column(col)
        new_state[i*4:i*4+4] = col
    return new_state

def sub_bytes(state):
    return [s_box[b] for b in state]

def shift_rows(state):
    new_state = state[:]
    new_state[1],new_state[5],new_state[9],new_state[13] = state[5],state[9],state[13],state[1]
    new_state[2],new_state[6],new_state[10],new_state[14] = state[10],state[14],state[2],state[6]
    new_state[3],new_state[7],new_state[11],new_state[15] = state[15],state[3],state[7],state[11]
    return new_state

def add_round_key(state, round_key):
    return [s ^ k for s,k in zip(state, round_key)]

def key_expansion(key):
    Nk = 8  # 32-byte key
    Nr = 14
    # w will hold 4-byte words; we store as list of ints flattened
    w = [0] * (4 * (Nr + 1) * 4)  # large buffer flattening words for simplicity
    # initial key bytes into w[0..31]
    for i in range(32):
        w[i] = key[i]
    # generate remaining bytes
    for i in range(8, 4*(Nr+1)):
        temp = w[4*(i-1):4*i]
        if i % Nk == 0:
            # RotWord + SubWord + Rcon
            temp = temp[1:] + temp[:1]
            temp = [s_box[b] for b in temp]
            temp[0] ^= Rcon[(i//Nk)-1]
        elif i % Nk == 4:
            temp = [s_box[b] for b in temp]
        for j in range(4):
            w[4*i + j] = w[4*(i-Nk) + j] ^ temp[j]
    # build round keys (list of 16-byte lists)
    round_keys = []
    for r in range(Nr+1):
        round_keys.append(w[16*r:16*(r+1)])
    return round_keys

def aes_encrypt_block(block, round_keys):
    state = list(block)
    Nr = 14
    state = add_round_key(state, round_keys[0])
    for rnd in range(1, Nr):
        state = sub_bytes(state)
        state = shift_rows(state)
        state = mix_columns(state)
        state = add_round_key(state, round_keys[rnd])
    state = sub_bytes(state)
    state = shift_rows(state)
    state = add_round_key(state, round_keys[Nr])
    # return bytes of state
    return bytes([x & 0xFF for x in state])

# ---------- AES-256 CTR CSPRNG (C-equivalent) ----------
class AESCTR_CSPRNG:
    def __init__(self, seed: bytes, iv: bytes = None):
        # seed: raw bytes (not str). If you have string, encode it first.
        if not isinstance(seed, (bytes, bytearray)):
            raise TypeError("seed must be bytes")
        # key := SHA3-256(seed)
        key = sha3_256(seed) if hasattr(sha3_256(seed), "digest") else sha3_256(seed)
        if isinstance(key, str):
            # If your sha3_256 returned hex str, decode it
            key = bytes.fromhex(key)
        if len(key) != 32:
            raise ValueError("sha3_256 must produce 32 bytes")
        self.round_keys = key_expansion(list(key))
        # IV := first 16 bytes of SHA3-256(seed || 0x01) if not provided
        if iv is None:
            tmp = seed + b'\x01'
            iv_full = sha3_256(tmp) if hasattr(sha3_256(tmp), "digest") else sha3_256(tmp)
            if isinstance(iv_full, str):
                iv_full = bytes.fromhex(iv_full)
            iv = iv_full[:16]
        if len(iv) != 16:
            raise ValueError("IV must be 16 bytes")
        # Use a 16-byte counter initialized to IV (big-endian increment)
        self.counter = bytearray(iv)
        self._buf = bytearray()

    def _increment_counter(self):
        for i in range(15, -1, -1):
            self.counter[i] = (self.counter[i] + 1) & 0xFF
            if self.counter[i] != 0:
                break

    def _get_block(self):
        # Use counter bytes directly as AES input block (no XOR with IV)
        block_input = bytes(self.counter)
        keystream = aes_encrypt_block(block_input, self.round_keys)
        self._increment_counter()
        return keystream

    def random_bytes(self, n):
        out = bytearray()
        while len(out) < n:
            out.extend(self._get_block())
        return bytes(out[:n])

    def random_int(self, nbits):
        nbytes = (nbits + 7) // 8
        rb = self.random_bytes(nbytes)
        return int.from_bytes(rb, 'big') >> (nbytes*8 - nbits)

# ---------- Example ----------
if __name__ == "__main__":
    import os
    seed = os.urandom(32)
    iv = sha3_256(seed + b'\x01')[:16]
    rng = AESCTR_CSPRNG(seed, iv)

    total_bytes = 100 * 1024 * 1024   # 100 MB
    chunk_size = 1024 * 1024          # 1 MB per iteration

    output_file = "random_bits.txt"

    with open(output_file, "w") as f:
        written = 0
        while written < total_bytes:
            to_generate = min(chunk_size, total_bytes - written)
            random_data = rng.random_bytes(to_generate)
            # Convert bytes to bits efficiently
            bits = ''.join(format(byte, '08b') for byte in random_data)
            f.write(bits)
            written += to_generate
            print(f"\rGenerated and written {written // (1024*1024)} MB...", end='', flush=True)

    print(f"\n100 MB random bits written to {output_file}")

