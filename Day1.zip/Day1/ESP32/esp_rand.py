import serial
import time
import sys

OUTPUT_FILE = "random_bits1.txt"
# TARGET_MB = 1

SERIAL_PORT = sys.argv[1]
BAUD_RATE = sys.argv[2] #921600
TARGET_SIZE = int(sys.argv[3])

def main():
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
    print(f"Connected to {SERIAL_PORT} at {BAUD_RATE} baud")

    target_bits = TARGET_SIZE * 1024 * 1024  # number of bits
    collected_bits = 0

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        while collected_bits < target_bits:
            data = ser.read(64)  # read bytes from serial
            if not data:
                continue

            # --- Handle both ASCII text and binary 0x00/0x01 bytes ---
            try:
                text = data.decode("utf-8", errors="ignore")
                # Remove unwanted characters and keep only 0 and 1
                bits_only = ''.join(ch for ch in text if ch in '01')
            except UnicodeDecodeError:
                pass

            if bits_only:
                f.write(bits_only)
                collected_bits += len(bits_only)

                # Print progress every ~1MB
                if collected_bits % (1024 * 1024) < 256:
                    progress = (collected_bits / target_bits) * 100
                    print(f"Progress: {progress:.2f}% ({collected_bits // 8 // 1024} KB)")

    ser.close()
    print(f"✅ Done! Saved ~{TARGET_SIZE} MB worth of pure bits to {OUTPUT_FILE}")

if __name__ == "__main__":
    main()