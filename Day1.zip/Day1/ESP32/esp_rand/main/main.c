#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_random.h"
#include "driver/uart.h"

#define CHUNK_SIZE 64
#define UART_PORT_NUM      UART_NUM_0
#define UART_BAUD_RATE     921600
#define TAG "RANDOM_GEN"

void app_main(void)
{
    const uart_config_t uart_config = {
        .baud_rate = UART_BAUD_RATE,
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE
    };
    uart_param_config(UART_PORT_NUM, &uart_config);
    uart_driver_install(UART_PORT_NUM, 2048, 0, 0, NULL, 0);

    ESP_LOGI(TAG, "Starting continuous random bit generation...");

    uint32_t rnd;
    while (1) {
        for (int i = 0; i < CHUNK_SIZE; i++) {
            rnd = esp_random();
            // Convert each bit of rnd (32 bits) into ASCII '0'/'1'
            for (int b = 31; b >= 0; b--) {
                putchar(((rnd >> b) & 1) ? '1' : '0');
            }
        }
        printf("\n");  // one line per chunk
        vTaskDelay(pdMS_TO_TICKS(1));
    }
}