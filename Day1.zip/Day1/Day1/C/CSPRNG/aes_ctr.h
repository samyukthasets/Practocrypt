#ifndef AES_CTR_H
#define AES_CTR_H

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "seed_expander.h"


/* AES constants */
#define AES_BLOCK_SIZE 16
/* AES-256: Nk = 8, Nr = 14, round key bytes = 16*(Nr+1) = 240 */
#define AES256_NK 8
#define AES256_NR 14
#define AES256_ROUND_KEY_BYTES (16*(AES256_NR+1))

/* PRNG state */
typedef struct {
    uint8_t key[32];                      /* AES-256 key (derived) */
    uint8_t roundKeys[AES256_ROUND_KEY_BYTES];
    uint8_t counter[16];                  /* 128-bit counter (nonce||ctr) */
} ctr_prng_t;

void ctr_prng_init_from_seed(ctr_prng_t *prng, const uint8_t *seed, size_t seedlen);

void ctr_prng_get_bytes(ctr_prng_t *prng, uint8_t *out, size_t n);

#endif